"""
Spectrum Unfolding Workflow Module

Provides complete workflow for neutron spectrum unfolding using:
- IRDFF-II cross sections from the IAEA database
- GRAVEL/MLEM iterative solvers
- MCNP spectrum as initial guess
- Response matrix construction from reaction cross sections

This module implements the methodology described in:
- Matzke, H., "Unfolding of Particle Spectra", PTB Report PTB-N-19 (1994)
- Reginatto, M., "The 'Few-Channel' Unfolding Programs in the UMG Package",
  PTB Report PTB-N-6 (2003)

References for IRDFF-II:
- A. Trkov et al., Nuclear Data Sheets 163, 1-108 (2020)
"""

from __future__ import annotations

from dataclasses import dataclass, field
import hashlib
from copy import deepcopy
from math import exp, log
from pathlib import Path
import re
from typing import Any, Dict, List, Optional, Sequence, Tuple, Union

import numpy as np

# FluxForge imports
from fluxforge.core.unfolding_diagnostics import merge_flux_diagnostics
from fluxforge.core.unfolding_inputs import require_nonnegative
from fluxforge.data.irdff import (
    IRDFFDatabase,
    IRDFFCrossSection,
    get_flux_wire_energy_groups,
    get_activation_energy_groups,
    build_response_matrix,
    IRDFF_REACTIONS,
)
from fluxforge.data.flux_wire_unfolding import (
    get_flux_wire_isotope_fraction,
    load_flux_wire_sample_defaults,
)
from fluxforge.data.group_structures import get_group_structure
from fluxforge.data.nndc import Isotope
from fluxforge.physics.monitor_response import MonitorResponseSpec, build_monitor_response
from fluxforge.physics.monitor_response import _validate_cross_section
from fluxforge.uncertainty.covariance import covariance_matrix, covariance_factor
from fluxforge.uncertainty.reaction_rate_budget import RateUncertaintyBudget, rate_covariance as budget_covariance
from fluxforge.solvers.iterative import gravel, mlem, IterativeSolution
from fluxforge.unfolding import MLSeedUnfolder, MaxedUnfolder, RMLEUnfolder


# =============================================================================
# Data Classes
# =============================================================================


_AVOGADRO = 6.02214076e23
_BARN_TO_CM2 = 1.0e-24
_FLUX_WIRE_SAMPLE_DEFAULTS = load_flux_wire_sample_defaults()


def _get_reaction_metadata(reaction: str) -> Dict[str, Any]:
    """Return IRDFF metadata for one reaction when available."""
    for category in IRDFF_REACTIONS.values():
        if reaction in category:
            return dict(category[reaction])
    return {}


def _canonical_isotope_or_none(name: str) -> Optional[str]:
    """Return a canonical isotope string when parsing succeeds."""
    try:
        return Isotope.from_string(name).name
    except Exception:
        return None


def _reaction_target_and_product(reaction: str) -> Tuple[Optional[str], Optional[str]]:
    """Extract target and product isotopes from one reaction identifier."""
    metadata = _get_reaction_metadata(reaction)
    target = metadata.get("target")
    product = metadata.get("product")
    if target and product:
        return str(target), str(product)

    match = re.match(r"^\s*([A-Za-z]+-\d+m?)\([^)]*\)([A-Za-z]+-\d+m?)\s*$", reaction)
    if match:
        return match.group(1), match.group(2)
    return None, None


def _row_key_label(key: Any) -> str:
    """Readable label for a response-row physics key."""
    if isinstance(key, tuple) and len(key) == 3:
        reaction, cover, shielding = key
        if (cover, shielding) == ("bare", "unshielded"):
            return str(reaction)
        return f"{reaction} [{cover}; {shielding}]"
    return str(key)


@dataclass
class FluxWireMeasurement:
    """
    Container for a flux wire measurement result.

    Attributes
    ----------
    reaction : str
        Reaction identifier (e.g., 'Ti-46(n,p)Sc-46')
    activity_Bq : float
        Measured activity at EOI in Bq
    uncertainty_Bq : float
        Uncertainty in Bq
    saturation_factor : float
        Saturation correction factor
    decay_factor : float
        Decay correction factor
    irradiation_time : float
        Irradiation time in seconds
    cooling_time : float
        Cooling time in seconds
    sample_mass_g : float
        Sample mass in grams
    isotope_abundance : float
        Isotope abundance (0-1)
    rate_per_atom : float | None
        Optional pre-normalized reaction rate in reactions/atom/s. When set,
        this bypasses the activity-to-rate conversion path.
    sample_id : str | None
        Physical monitor identity (keeps replicate/bare/covered rows distinct).
    cover : str | None
        Cover label (``None``/``"bare"`` or e.g. ``"Cd"``). A covered
        measurement must also carry a ``response_spec`` with a matching
        :class:`~fluxforge.physics.monitor_response.CoverLayer`.
    response_spec : MonitorResponseSpec | None
        Physical response definition (cover transmission, self-shielding).
    """

    reaction: str
    activity_Bq: float
    uncertainty_Bq: float = 0.0
    saturation_factor: Optional[float] = None
    decay_factor: Optional[float] = None
    irradiation_time: float = 0.0
    cooling_time: float = 0.0
    sample_mass_g: Optional[float] = None
    isotope_abundance: Optional[float] = None
    rate_per_atom: Optional[float] = None
    sample_id: Optional[str] = None
    cover: Optional[str] = None
    response_spec: Optional[MonitorResponseSpec] = None
    element_mass_fraction: float = 1.0
    rate_uncertainty_budget: Optional[RateUncertaintyBudget] = None

    @property
    def row_key(self) -> Tuple[str, str, str]:
        """Physics identity of this measurement's response row."""
        if self.response_spec is not None:
            return self.response_spec.physics_key
        return (self.reaction, self.cover or "bare", "unshielded")

    @property
    def target_isotope(self) -> Optional[str]:
        """Target isotope parsed from the reaction identifier."""
        target, _ = _reaction_target_and_product(self.reaction)
        return target

    @property
    def product_isotope(self) -> Optional[str]:
        """Activation product isotope parsed from the reaction identifier."""
        _, product = _reaction_target_and_product(self.reaction)
        return product

    @property
    def effective_isotope_abundance(self) -> float:
        """Resolved target-isotope abundance fraction."""
        if self.isotope_abundance is not None:
            if not np.isfinite(self.isotope_abundance) or not 0 < self.isotope_abundance <= 1:
                raise ValueError(f"{self.reaction}: isotope_abundance must be finite and in (0, 1]")
            return float(self.isotope_abundance)

        target = self.target_isotope
        if target:
            try:
                element = target.split("-", 1)[0]
                default_fraction = get_flux_wire_isotope_fraction(self.reaction, element)
                if default_fraction > 0.0 and not np.isclose(default_fraction, 1.0):
                    return float(default_fraction)
            except Exception:
                pass

            canonical_target = _canonical_isotope_or_none(target)
            if canonical_target is not None:
                isotope = Isotope.from_string(canonical_target)
                if isotope.abundance is not None and isotope.abundance > 0.0:
                    return float(isotope.abundance)

        raise ValueError(f"{self.reaction}: supply isotope_abundance; natural abundance unavailable")

    @property
    def target_atom_count(self) -> float:
        """Number of target atoms in the measured wire."""
        if self.sample_mass_g is None:
            raise ValueError(f"{self.reaction}: sample_mass_g is required to normalize per atom")
        if not np.isfinite(self.sample_mass_g) or self.sample_mass_g <= 0.0:
            raise ValueError(f"{self.reaction}: sample_mass_g must be finite and positive")
        if not np.isfinite(self.element_mass_fraction) or not 0 < self.element_mass_fraction <= 1:
            raise ValueError(f"{self.reaction}: element_mass_fraction must be finite and in (0, 1]")

        target = self.target_isotope
        if target is None:
            raise ValueError(f"{self.reaction}: target isotope cannot be resolved")

        element = target.split("-", 1)[0]
        atomic_mass = None
        defaults = _FLUX_WIRE_SAMPLE_DEFAULTS.get(element, {})
        if defaults:
            atomic_mass = defaults.get("atomic_mass")

        if atomic_mass is None:
            canonical_target = _canonical_isotope_or_none(target)
            if canonical_target is not None:
                atomic_mass = Isotope.from_string(canonical_target).atomic_mass

        if atomic_mass is None or atomic_mass <= 0.0:
            raise ValueError(f"{self.reaction}: target atomic mass is unavailable")

        abundance = self.effective_isotope_abundance
        if not np.isfinite(abundance) or not 0 < abundance <= 1:
            raise ValueError(f"{self.reaction}: isotope_abundance must be finite and in (0, 1]")

        return float((self.sample_mass_g / atomic_mass) * _AVOGADRO * abundance * self.element_mass_fraction)

    @property
    def effective_saturation_factor(self) -> float:
        """Explicit saturation factor, else one derived from irradiation time."""
        if self.saturation_factor is not None:
            return float(self.saturation_factor)
        if self.irradiation_time <= 0.0:
            raise ValueError(
                f"{self.reaction}: give saturation_factor or irradiation_time; "
                "saturation is never assumed"
            )
        decay_constant = log(2.0) / self._product_half_life_s()
        return float(-np.expm1(-decay_constant * self.irradiation_time))

    def _product_half_life_s(self) -> float:
        product = self.product_isotope
        canonical_product = _canonical_isotope_or_none(product) if product else None
        half_life_s = (
            Isotope.from_string(canonical_product).half_life_s if canonical_product else None
        )
        if half_life_s is None or half_life_s <= 0.0 or half_life_s == float("inf"):
            raise ValueError(f"{self.reaction}: product half-life unavailable")
        return float(half_life_s)

    @property
    def effective_decay_factor(self) -> float:
        """Explicit decay factor, else from cooling time (1 for EOI activity)."""
        if self.decay_factor is not None:
            return float(self.decay_factor)
        if self.cooling_time <= 0.0:
            return 1.0
        decay_constant = log(2.0) / self._product_half_life_s()
        return float(exp(-decay_constant * self.cooling_time))

    @property
    def reaction_rate_per_atom(self) -> float:
        """Calculate reaction rate per target atom per second."""
        if self.rate_per_atom is not None:
            if not np.isfinite(self.rate_per_atom) or self.rate_per_atom < 0:
                raise ValueError(f"{self.reaction}: rate_per_atom must be finite and nonnegative")
            return float(self.rate_per_atom)
        if not np.isfinite(self.activity_Bq) or self.activity_Bq < 0:
            raise ValueError(f"{self.reaction}: activity_Bq must be finite and nonnegative")
        n_target_atoms = self.target_atom_count
        saturation = self.effective_saturation_factor
        decay = self.effective_decay_factor
        denominator = n_target_atoms * saturation * decay
        if not np.isfinite(denominator) or denominator <= 0.0:
            raise ValueError(f"{self.reaction}: rate normalization must be finite and positive")
        return self.activity_Bq / denominator

    @property
    def relative_uncertainty(self) -> float:
        """Relative uncertainty as fraction."""
        if self.activity_Bq > 0:
            return self.uncertainty_Bq / self.activity_Bq
        return 0.0


@dataclass
class UnfoldingResult:
    """
    Container for spectrum unfolding results.

    Attributes
    ----------
    energy_edges : np.ndarray
        Energy group boundaries in eV
    flux : np.ndarray
        Unfolded flux spectrum (per unit energy)
    flux_uncertainty : np.ndarray
        Flux uncertainties
    energy_midpoints : np.ndarray
        Group midpoint energies in eV
    energy_widths : np.ndarray
        Group widths in eV
    reactions_used : List[str]
        Reactions used in unfolding
    response_matrix : np.ndarray
        Response matrix used
    measured_rates : np.ndarray
        Input measured reaction rates
    predicted_rates : np.ndarray
        Predicted rates from unfolded spectrum
    chi_squared : float
        Chi-squared per degree of freedom
    iterations : int
        Number of iterations performed
    converged : bool
        Whether algorithm converged
    method : str
        Unfolding method used ('GRAVEL' or 'MLEM')
    initial_guess_source : str
        Source of initial guess ('uniform', 'MCNP', 'user')
    metadata : Dict[str, Any]
        Additional metadata
    """

    energy_edges: np.ndarray
    flux: np.ndarray
    flux_uncertainty: np.ndarray = field(default_factory=lambda: np.array([]))
    energy_midpoints: np.ndarray = field(default_factory=lambda: np.array([]))
    energy_widths: np.ndarray = field(default_factory=lambda: np.array([]))
    reactions_used: List[str] = field(default_factory=list)
    response_matrix: np.ndarray = field(default_factory=lambda: np.array([]))
    measured_rates: np.ndarray = field(default_factory=lambda: np.array([]))
    predicted_rates: np.ndarray = field(default_factory=lambda: np.array([]))
    chi_squared: float = 0.0
    iterations: int = 0
    converged: bool = False
    method: str = "GRAVEL"
    initial_guess_source: str = "uniform"
    metadata: Dict[str, Any] = field(default_factory=dict)

    def __post_init__(self):
        """Calculate derived quantities."""
        if len(self.energy_midpoints) == 0 and len(self.energy_edges) > 1:
            self.energy_midpoints = np.sqrt(
                self.energy_edges[:-1] * self.energy_edges[1:]
            )
        if len(self.energy_widths) == 0 and len(self.energy_edges) > 1:
            self.energy_widths = self.energy_edges[1:] - self.energy_edges[:-1]

    @property
    def n_groups(self) -> int:
        """Number of energy groups."""
        return len(self.flux)

    @property
    def integral_flux(self) -> float:
        """Total integral flux."""
        return float(np.sum(self.flux * self.energy_widths))

    @property
    def thermal_flux(self, e_max: float = 0.55) -> float:
        """Thermal flux (E < Cd cutoff)."""
        mask = self.energy_midpoints < e_max
        return float(np.sum(self.flux[mask] * self.energy_widths[mask]))

    @property
    def fast_flux(self, e_min: float = 1e5) -> float:
        """Fast flux (E > 100 keV)."""
        mask = self.energy_midpoints > e_min
        return float(np.sum(self.flux[mask] * self.energy_widths[mask]))

    def get_flux_at_energy(self, energy_eV: float) -> float:
        """Get flux at a specific energy by interpolation."""
        return float(np.interp(energy_eV, self.energy_midpoints, self.flux))

    def to_lethargy(self) -> Tuple[np.ndarray, np.ndarray]:
        """
        Convert to lethargy representation (E * φ(E)).

        Returns
        -------
        lethargy : np.ndarray
            Lethargy values (u = ln(E_ref/E))
        flux_per_lethargy : np.ndarray
            Flux per unit lethargy (E * φ(E))
        """
        e_ref = 20e6  # 20 MeV reference
        lethargy = np.log(e_ref / self.energy_midpoints)
        flux_per_lethargy = self.energy_midpoints * self.flux
        return lethargy, flux_per_lethargy


# =============================================================================
# Spectrum Unfolding Workflow
# =============================================================================


class SpectrumUnfolder:
    """
    Main class for neutron spectrum unfolding.

    Combines IRDFF-II cross sections with iterative solvers to unfold
    measured reaction rates into continuous neutron spectra.

    Examples
    --------
    >>> unfolder = SpectrumUnfolder()
    >>> unfolder.add_reaction("Ti-46(n,p)Sc-46", activity=1.23e5, uncertainty=1.23e3)
    >>> unfolder.add_reaction("Ni-58(n,p)Co-58", activity=4.56e5, uncertainty=4.56e3)
    >>> unfolder.set_mcnp_initial_guess("spectrum.csv")
    >>> result = unfolder.unfold(method="GRAVEL")
    """

    def __init__(
        self,
        energy_structure: str = "flux_wire",
        custom_energy_edges: Optional[np.ndarray] = None,
        verbose: bool = True,
    ):
        """
        Initialize spectrum unfolder.

        Parameters
        ----------
        energy_structure : str
            'flux_wire', 'activation', or any exact standard structure from
            :mod:`fluxforge.data.group_structures` (e.g. 'VITAMIN-J',
            'VITAMIN-J-175', 'CCFE-709', 'SAND-II-725')
        custom_energy_edges : np.ndarray, optional
            Custom energy edges in eV (overrides energy_structure)
        verbose : bool
            Print status messages
        """
        self.verbose = verbose

        # Set up energy structure
        if custom_energy_edges is not None:
            self.energy_edges = custom_energy_edges
        elif energy_structure == "flux_wire":
            self.energy_edges = get_flux_wire_energy_groups()
        elif energy_structure == "activation":
            self.energy_edges = get_activation_energy_groups()
        else:
            self.energy_edges = get_group_structure(energy_structure)

        self.n_groups = len(self.energy_edges) - 1

        # Initialize IRDFF database
        self.irdff_db = IRDFFDatabase(verbose=verbose)

        # Measurement storage
        self.measurements: List[FluxWireMeasurement] = []

        # Initial guess
        self.initial_flux: Optional[np.ndarray] = None
        self.initial_guess_source = "uniform"

        # Response matrix (built when needed)
        self._response_matrix: Optional[np.ndarray] = None
        self._response_row_metadata: List[Dict[str, Any]] = []
        self._reaction_list: List[str] = []

        if self.verbose:
            print(f"SpectrumUnfolder initialized:")
            print(f"  Energy groups: {self.n_groups}")
            print(
                f"  Energy range: {self.energy_edges[0]:.2e} - {self.energy_edges[-1]:.2e} eV"
            )

    def add_reaction(
        self,
        reaction: str,
        activity_Bq: float,
        uncertainty_Bq: float = 0.0,
        saturation_factor: Optional[float] = None,
        decay_factor: Optional[float] = None,
        rate_per_atom: Optional[float] = None,
        **kwargs,
    ) -> None:
        """
        Add a measured reaction for unfolding.

        Parameters
        ----------
        reaction : str
            Reaction identifier (e.g., 'Ti-46(n,p)Sc-46')
        activity_Bq : float
            Measured activity at EOI in Bq
        uncertainty_Bq : float
            Uncertainty in Bq
        saturation_factor : float, optional
            Saturation correction (else derived from ``irradiation_time``)
        decay_factor : float, optional
            Decay correction (else derived from ``cooling_time``; 1 at EOI)
        rate_per_atom : float, optional
            Pre-normalized reaction rate in reactions/atom/s. Use this when the
            upstream workflow already converted activity to reaction rate.
        **kwargs
            Additional parameters passed to FluxWireMeasurement
        """
        meas = FluxWireMeasurement(
            reaction=reaction,
            activity_Bq=activity_Bq,
            uncertainty_Bq=uncertainty_Bq,
            saturation_factor=saturation_factor,
            decay_factor=decay_factor,
            rate_per_atom=rate_per_atom,
            **kwargs,
        )
        self.measurements.append(meas)

        # Invalidate cached response matrix
        self._response_matrix = None

        if self.verbose:
            print(f"  Added: {reaction} - {activity_Bq:.3e} ± {uncertainty_Bq:.3e} Bq")

    def add_measurements_from_dataframe(
        self,
        df,
        reaction_col: str = "reaction",
        activity_col: str = "activity_Bq",
        uncertainty_col: str = "uncertainty_Bq",
    ) -> None:
        """
        Add measurements from a pandas DataFrame.

        Parameters
        ----------
        df : DataFrame
            DataFrame with reaction data
        reaction_col : str
            Column name for reaction identifier
        activity_col : str
            Column name for activity in Bq
        uncertainty_col : str
            Column name for uncertainty in Bq
        """
        for _, row in df.iterrows():
            self.add_reaction(
                reaction=row[reaction_col],
                activity_Bq=row[activity_col],
                uncertainty_Bq=row.get(uncertainty_col, 0.0),
            )

    def set_mcnp_initial_guess(
        self,
        spectrum_file: Union[str, Path],
        energy_col: int = 0,
        flux_col: int = 1,
        skiprows: int = 0,
        energy_units: str = "MeV",
        flux_units: str = "per_cm2_per_s",
    ) -> None:
        """
        Load MCNP spectrum as initial guess.

        Parameters
        ----------
        spectrum_file : str or Path
            Path to spectrum file (CSV or text)
        energy_col : int
            Column index for energy
        flux_col : int
            Column index for flux
        skiprows : int
            Number of header rows to skip
        energy_units : str
            Units of energy in file ('MeV' or 'eV')
        flux_units : str
            Units of flux in file
        """
        spectrum_file = Path(spectrum_file)

        if spectrum_file.suffix == ".csv":
            import csv

            with open(spectrum_file, "r") as f:
                reader = csv.reader(f)
                for _ in range(skiprows):
                    next(reader)
                data = list(reader)

            energies = []
            fluxes = []
            for row in data:
                try:
                    e = float(row[energy_col])
                    f = float(row[flux_col])
                    energies.append(e)
                    fluxes.append(f)
                except (ValueError, IndexError):
                    continue

            energies = np.array(energies)
            fluxes = np.array(fluxes)
        else:
            data = np.loadtxt(spectrum_file, skiprows=skiprows)
            energies = data[:, energy_col]
            fluxes = data[:, flux_col]

        # Convert energy units to eV
        if energy_units.lower() == "mev":
            energies = energies * 1e6

        # Interpolate to our energy structure
        group_centers = np.sqrt(self.energy_edges[:-1] * self.energy_edges[1:])
        self.initial_flux = np.interp(group_centers, energies, fluxes, left=0, right=0)

        # Ensure positive
        self.initial_flux = np.maximum(self.initial_flux, 1e-30)

        self.initial_guess_source = "MCNP"

        if self.verbose:
            print(f"  Loaded MCNP spectrum from {spectrum_file}")
            print(f"  Interpolated to {self.n_groups} groups")

    def set_initial_guess(
        self,
        flux: np.ndarray,
        source: str = "user",
    ) -> None:
        """
        Set custom initial guess.

        Parameters
        ----------
        flux : np.ndarray
            Initial flux guess (length = n_groups)
        source : str
            Description of source
        """
        if len(flux) != self.n_groups:
            raise ValueError(f"Flux length {len(flux)} != n_groups {self.n_groups}")

        self.initial_flux = require_nonnegative("initial_flux", flux).reshape(-1)
        self.initial_guess_source = source

    def _build_response_matrix(self) -> Tuple[np.ndarray, List[str], np.ndarray]:
        """Build response matrix from measurements."""
        edges = np.asarray(self.energy_edges, dtype=float)
        if (edges.ndim != 1 or len(edges) < 2 or not np.all(np.isfinite(edges))
                or np.any(edges <= 0) or np.any(np.diff(edges) <= 0)):
            raise ValueError("Current energy edges must be finite, positive and strictly increasing")
        self.n_groups = len(edges) - 1
        fingerprint = hashlib.sha256()
        fingerprint.update(str(id(self.irdff_db)).encode())
        fingerprint.update(edges.astype("<f8").tobytes())
        def bind(value):
            fingerprint.update(repr(value).encode("utf-8") + b"\0")
        def bind_xs(xs):
            _validate_cross_section(xs)
            bind((xs.source, xs.source_sha256, xs.evaluation_key, xs.interpolation, xs.threshold_eV))
            for values in (xs.energies, xs.cross_sections, xs.uncertainties):
                array = np.asarray(values, dtype="<f8")
                bind(array.shape)
                fingerprint.update(array.tobytes())
        archive = getattr(self.irdff_db, "archive_path", None)
        bind((str(archive), getattr(self.irdff_db, "expected_archive_sha256", None)))
        source_digests = {}
        if archive is not None:
            for source in (Path(archive), Path(archive).with_name("IRDFF-II.abs.txt")):
                if source.is_file():
                    source_digests[source.name] = hashlib.sha256(source.read_bytes()).hexdigest()
            expected = getattr(self.irdff_db, "expected_archive_sha256", None)
            if expected and source_digests.get(Path(archive).name) != expected:
                raise ValueError("Pinned evaluated archive is missing or changed")
        reactions = [m.reaction for m in self.measurements]
        for m in self.measurements:
            covered = m.cover not in (None, "", "bare")
            if covered and (m.response_spec is None or m.response_spec.cover is None):
                raise ValueError(
                    f"Measurement {m.sample_id or m.reaction} is labeled cover={m.cover!r} "
                    "but has no response_spec with a CoverLayer; a bare response row "
                    "would be used for a covered monitor"
                )
            if m.response_spec is not None and m.response_spec.reaction != m.reaction:
                raise ValueError("response_spec.reaction must match the measurement reaction")
            spec = m.response_spec
            if spec is not None:
                if spec.cover is not None:
                    spec.cover.__post_init__()
                if spec.shielding is not None:
                    spec.shielding.__post_init__()
            bind((m.reaction, m.sample_id, m.cover, None if spec is None else
                  (spec.observation_id, spec.sample_id, spec.physics_key)))
            xs = self.irdff_db.get_cross_section(m.reaction)
            if xs is None:
                raise ValueError(f"No evaluated cross section for {m.reaction}")
            bind_xs(xs)
            if archive is not None and xs.source_sha256 :
                if xs.source_sha256 != source_digests.get(Path(archive).name):
                    raise ValueError("Evaluated source changed; construct a fresh IRDFFDatabase")
            if spec is not None and spec.cover is not None:
                cover_xs = self.irdff_db.get_cover_cross_section(spec.cover.material, spec.cover.attenuation)
                if cover_xs is None:
                    raise ValueError("Evaluated cover data is required")
                bind_xs(cover_xs)
                if (archive is not None and cover_xs.source_sha256 and
                        cover_xs.source_sha256 != source_digests.get("IRDFF-II.abs.txt")):
                    raise ValueError("Evaluated cover source changed; construct a fresh IRDFFDatabase")
        current_fingerprint = fingerprint.hexdigest()
        if (getattr(self, "_response_matrix", None) is not None and
                getattr(self, "_response_fingerprint", None) == current_fingerprint):
            return self._response_matrix, self._reaction_list, self._response_unc

        response, valid_reactions, uncertainties = build_response_matrix(
            reactions=reactions,
            energy_edges=self.energy_edges,
            db=self.irdff_db,
            verbose=self.verbose,
        )
        self._response_row_metadata = []
        for index, m in enumerate(self.measurements):
            if m.response_spec is None:
                reaction_xs = self.irdff_db.get_cross_section(m.reaction)
                self._response_row_metadata.append(
                    {"observation_id": f"{m.sample_id or m.reaction}:{index}",
                     "sample_id": m.sample_id, "reaction": m.reaction, "cover": None,
                     "self_shielding": None,
                     "reaction_source": reaction_xs.source,
                     "reaction_evaluation_key": reaction_xs.evaluation_key,
                     "reaction_source_sha256": reaction_xs.source_sha256,
                     "reaction_interpolation": reaction_xs.interpolation}
                )
                continue
            row = build_monitor_response(m.response_spec, self.energy_edges, self.irdff_db)
            response[index] = row.group_cross_section_barn
            uncertainties[index] = row.group_uncertainty_barn
            self._response_row_metadata.append(row.metadata)

        group_widths = np.diff(self.energy_edges).reshape(1, -1)
        response = response * group_widths * _BARN_TO_CM2
        uncertainties = uncertainties * group_widths * _BARN_TO_CM2

        self._response_matrix = response
        self._reaction_list = valid_reactions
        self._response_unc = uncertainties
        self._response_fingerprint = current_fingerprint

        return response, valid_reactions, uncertainties

    def _prepare_support_filtered_problem(
        self,
        response_matrix: np.ndarray,
        measured_rates: np.ndarray,
        rate_uncertainties: np.ndarray,
        initial_flux: np.ndarray,
        *,
        support_threshold: Optional[float] = None,
        support_metric: str = "prior_contribution",
        floor: float = 1e-30,
    ) -> Dict[str, Any]:
        """Reduce the unfolding problem to energy bins materially constrained by the prior."""
        n_groups = response_matrix.shape[1]
        active_mask = np.ones(n_groups, dtype=bool)
        support_scores = np.ones(n_groups, dtype=float)
        fixed_prediction = np.zeros_like(measured_rates, dtype=float)

        if (
            support_threshold is None
            or support_threshold <= 0.0
            or initial_flux.size != n_groups
        ):
            return {
                "response": response_matrix,
                "measurements": measured_rates,
                "uncertainties": rate_uncertainties,
                "initial_flux": initial_flux,
                "active_mask": active_mask,
                "support_scores": support_scores,
                "fixed_prediction": fixed_prediction,
            }

        if support_metric == "prior_contribution":
            group_contributions = response_matrix * initial_flux.reshape(1, -1)
            total_prediction = np.sum(group_contributions, axis=1, keepdims=True)
            support_scores = np.max(
                group_contributions / np.maximum(total_prediction, floor),
                axis=0,
            )
        elif support_metric == "response_sum":
            group_sensitivity = np.sum(response_matrix, axis=0)
            max_sensitivity = float(np.max(group_sensitivity)) if group_sensitivity.size else 0.0
            if max_sensitivity > 0.0:
                support_scores = group_sensitivity / max_sensitivity
            else:
                support_scores = np.zeros(n_groups, dtype=float)
        else:
            raise ValueError(
                f"Unknown support metric: {support_metric}. Use 'prior_contribution' or 'response_sum'."
            )

        active_mask = support_scores >= float(support_threshold)
        if not np.any(active_mask) or np.all(active_mask):
            return {
                "response": response_matrix,
                "measurements": measured_rates,
                "uncertainties": rate_uncertainties,
                "initial_flux": initial_flux,
                "active_mask": np.ones(n_groups, dtype=bool),
                "support_scores": support_scores,
                "fixed_prediction": fixed_prediction,
            }

        fixed_prediction = response_matrix[:, ~active_mask] @ initial_flux[~active_mask]
        adjusted_measurements = np.maximum(measured_rates - fixed_prediction, floor)

        return {
            "response": response_matrix[:, active_mask],
            "measurements": adjusted_measurements,
            "uncertainties": rate_uncertainties,
            "initial_flux": initial_flux[active_mask],
            "active_mask": active_mask,
            "support_scores": support_scores,
            "fixed_prediction": fixed_prediction,
        }

    def _build_prior_shape_basis(
        self,
        prior_flux: np.ndarray,
        basis_edges: np.ndarray,
        *,
        floor: float = 1e-30,
    ) -> Dict[str, Any]:
        """
        Build a coarse prior-shaped basis for few-channel unfolding.

        Each coarse coefficient scales the prior spectrum within one contiguous
        energy interval. This keeps the solve dimension aligned with the number
        of informative monitors while preserving the prior shape inside each
        coarse interval.
        """
        native_midpoints = np.sqrt(
            np.maximum(self.energy_edges[:-1], floor)
            * np.maximum(self.energy_edges[1:], floor)
        )
        resolved_edges = np.asarray(basis_edges, dtype=float).reshape(-1)
        if resolved_edges.size < 2:
            raise ValueError("basis_edges must contain at least two boundaries")
        if not np.all(np.diff(resolved_edges) > 0.0):
            raise ValueError("basis_edges must be strictly increasing")
        if resolved_edges[0] > float(self.energy_edges[0]) or resolved_edges[-1] < float(
            self.energy_edges[-1]
        ):
            raise ValueError(
                "basis_edges must span the full unfolding energy range "
                f"({self.energy_edges[0]:.3e} to {self.energy_edges[-1]:.3e} eV)"
            )

        basis_columns: List[np.ndarray] = []
        active_edges: List[float] = [float(resolved_edges[0])]
        for index, (e_lo, e_hi) in enumerate(zip(resolved_edges[:-1], resolved_edges[1:])):
            if index == len(resolved_edges) - 2:
                mask = (native_midpoints >= e_lo) & (native_midpoints <= e_hi)
            else:
                mask = (native_midpoints >= e_lo) & (native_midpoints < e_hi)
            if not np.any(mask):
                continue

            column = np.zeros_like(prior_flux, dtype=float)
            column[mask] = np.maximum(prior_flux[mask], floor)
            if not np.any(column > floor):
                column[mask] = 1.0
            basis_columns.append(column)
            active_edges.append(float(e_hi))

        if not basis_columns:
            raise ValueError("basis_edges did not capture any native energy groups")

        basis_matrix = np.column_stack(basis_columns)
        reconstructed_prior = basis_matrix @ np.ones(basis_matrix.shape[1], dtype=float)
        if not np.allclose(reconstructed_prior, np.maximum(prior_flux, floor)):
            raise ValueError("basis_edges do not partition the prior spectrum cleanly")

        return {
            "basis_matrix": basis_matrix,
            "basis_edges": np.asarray(active_edges, dtype=float),
            "n_basis_groups": int(basis_matrix.shape[1]),
        }

    def _aggregate_duplicate_reaction_rows(
        self,
        response_matrix: np.ndarray,
        valid_reactions: List[str],
        measured_rates: np.ndarray,
        rate_uncertainties: np.ndarray,
        response_uncertainties: Optional[np.ndarray] = None,
        *,
        floor: float = 1e-30,
        row_keys: Optional[Sequence[Any]] = None,
        observation_ids: Optional[Sequence[str]] = None,
        uncertainty_models: Optional[Sequence[Any]] = None,
        measurement_covariance: Optional[np.ndarray] = None,
    ) -> Dict[str, Any]:
        """
        Aggregate repeated reaction rows using inverse-variance weighting.

        This is useful when multiple wire replicates map to the same reaction
        response row. Treating those replicates as fully independent rows
        artificially over-weights one response shape in the inversion.

        Keys nominate candidates only. Nominal operators, response uncertainty
        rows and supplied uncertainty models must match exactly. Tolerances
        would erase small physical differences, especially in cm2/eV units.
        """
        n = len(valid_reactions)
        covariance = (None if measurement_covariance is None else
                      covariance_matrix(measurement_covariance, n, "rate covariance"))
        response_matrix = require_nonnegative("response_matrix", response_matrix)
        measured_rates = require_nonnegative("measured_rates", measured_rates)
        rate_uncertainties = require_nonnegative("rate_uncertainties", rate_uncertainties)
        if response_matrix.ndim != 2 or response_matrix.shape[0] != n:
            raise ValueError("response_matrix must have one row per reaction")
        if measured_rates.shape != (n,) or rate_uncertainties.shape != (n,):
            raise ValueError("Measurements and uncertainties must align with response rows")
        if response_uncertainties is not None:
            response_uncertainties = require_nonnegative("response_uncertainties", response_uncertainties)
            if response_uncertainties.shape != response_matrix.shape:
                raise ValueError("Response uncertainties must align with response rows")
        if not np.isfinite(floor) or floor <= 0:
            raise ValueError("floor must be finite and positive")
        keys = list(row_keys) if row_keys is not None else list(valid_reactions)
        if len(keys) != n:
            raise ValueError("row_keys must align with valid_reactions")
        ids = list(observation_ids) if observation_ids is not None else [str(i) for i in range(n)]
        if len(ids) != n or len(set(ids)) != n:
            raise ValueError("observation_ids must be unique and align with response rows")
        models = list(uncertainty_models) if uncertainty_models is not None else [None] * n
        if len(models) != n:
            raise ValueError("uncertainty_models must align with response rows")
        order: List[Any] = []
        grouped_indices: Dict[Any, List[int]] = {}
        for idx, key in enumerate(keys):
            if key not in grouped_indices:
                grouped_indices[key] = []
                order.append(key)
            grouped_indices[key].append(idx)

        groups: List[List[int]] = []
        for key in order:
            partitions: List[List[int]] = []
            for idx in grouped_indices[key]:
                for partition in partitions:
                    first = partition[0]
                    if (valid_reactions[idx] == valid_reactions[first]
                            and np.array_equal(response_matrix[idx], response_matrix[first])
                            and (response_uncertainties is None or np.array_equal(
                                response_uncertainties[idx], response_uncertainties[first]))
                            and models[idx] == models[first]):
                        partition.append(idx)
                        break
                else:
                    partitions.append([idx])
            groups.extend(partitions)
        # Preserve first-observation order even when a key has multiple partitions.
        groups.sort(key=lambda indices: indices[0])
        memberships = [{"row_indices": indices, "observation_ids": [ids[i] for i in indices]}
                       for indices in groups]
        counts = {_row_key_label(key): len(grouped_indices[key]) for key in order}
        transform = np.zeros((len(groups), n))
        for out_index, indices in enumerate(groups):
            if covariance is None:
                sigma = np.maximum(rate_uncertainties[indices], floor)
                weights = (np.min(sigma) / sigma) ** 2
                weights /= weights.sum()
            else:
                block = covariance[np.ix_(indices, indices)]
                scale = float(np.max(np.abs(block)))
                ones = np.ones(len(indices))
                if scale == 0:
                    weights = ones / len(indices)
                    null_vectors = np.eye(len(indices))
                else:
                    values, vectors = np.linalg.eigh(block / scale)
                    positive = values > 20 * len(indices) * np.finfo(float).eps
                    null_vectors = vectors[:, ~positive]
                    null_projection = null_vectors @ (null_vectors.T @ ones)
                    if ones @ null_projection > 20 * len(indices) * np.finfo(float).eps:
                        weights = null_projection / (ones @ null_projection)
                    else:
                        inverse_one = (vectors[:, positive] / values[positive]) @ (vectors[:, positive].T @ ones)
                        weights = inverse_one / (ones @ inverse_one)
                common_rate = float(weights @ measured_rates[indices])
                deterministic_residual = null_vectors.T @ (measured_rates[indices] - common_rate)
                rate_scale = max(float(np.max(np.abs(measured_rates[indices]))), abs(common_rate))
                roundoff = (100 * len(indices) * np.finfo(float).eps * rate_scale *
                            max(1., float(np.sum(np.abs(weights)))))
                if deterministic_residual.size and np.max(np.abs(deterministic_residual)) > roundoff:
                    raise ValueError("Duplicate rates are incompatible with noiseless covariance directions")
            transform[out_index, indices] = weights
        # Form a Gram matrix instead of subtracting nearly equal covariance
        # terms. Singular shared errors can cancel exactly under BLUE weights.
        transformed_factor = (None if covariance is None else
                              transform @ covariance_factor(covariance))
        aggregated_covariance = (None if covariance is None else
                                 transformed_factor @ transformed_factor.T)
        has_duplicates = any(len(indices) > 1 for indices in groups)
        if not has_duplicates:
            return {
                "response": response_matrix,
                "reactions": list(valid_reactions),
                "measurements": measured_rates,
                "uncertainties": rate_uncertainties,
                "response_uncertainties": response_uncertainties,
                "measurement_covariance": covariance,
                "metadata": {
                    "applied": False,
                    "original_rows": int(len(valid_reactions)),
                    "aggregated_rows": int(len(valid_reactions)),
                    "reaction_counts": counts,
                    "memberships": memberships,
                    "aggregation_matrix": transform.tolist(),
                },
            }

        aggregated_response_rows: List[np.ndarray] = []
        aggregated_reactions: List[str] = []
        aggregated_measurements: List[float] = []
        aggregated_uncertainties: List[float] = []
        aggregated_response_unc_rows: List[np.ndarray] = []

        for out_index, indices in enumerate(groups):
            representative_idx = indices[0]
            reaction = valid_reactions[representative_idx]
            representative_row = np.asarray(response_matrix[representative_idx], dtype=float)
            sigmas = np.maximum(rate_uncertainties[indices], floor)
            scale = float(np.min(sigmas))
            weights = (scale / sigmas) ** 2
            weight_sum = float(np.sum(weights))
            aggregated_measurement = float(
                np.sum(weights * measured_rates[indices]) / weight_sum
            )
            aggregated_uncertainty = float(scale / np.sqrt(weight_sum))
            if len(indices) == 1:
                aggregated_measurement = float(measured_rates[representative_idx])
                aggregated_uncertainty = float(rate_uncertainties[representative_idx])
            if covariance is not None:
                aggregated_measurement = float(transform[out_index] @ measured_rates)
                aggregated_uncertainty = float(np.sqrt(aggregated_covariance[out_index, out_index]))

            aggregated_response_rows.append(representative_row)
            aggregated_reactions.append(reaction)
            aggregated_measurements.append(aggregated_measurement)
            aggregated_uncertainties.append(aggregated_uncertainty)

            if response_uncertainties is not None:
                aggregated_response_unc_rows.append(
                    np.asarray(response_uncertainties[representative_idx], dtype=float)
                )

        return {
            "response": np.asarray(aggregated_response_rows, dtype=float),
            "reactions": aggregated_reactions,
            "measurements": np.asarray(aggregated_measurements, dtype=float),
            "uncertainties": np.asarray(aggregated_uncertainties, dtype=float),
            "response_uncertainties": (
                np.asarray(aggregated_response_unc_rows, dtype=float)
                if response_uncertainties is not None
                else None
            ),
            "measurement_covariance": aggregated_covariance,
            "metadata": {
                "applied": True,
                "original_rows": int(len(valid_reactions)),
                "aggregated_rows": int(len(aggregated_reactions)),
                "reaction_counts": counts,
                "memberships": memberships,
                "aggregation_matrix": transform.tolist(),
            },
        }

    def unfold(
        self,
        method: str = "GRAVEL",
        max_iterations: int = 1000,
        tolerance: float = 1e-4,
        chi2_tolerance: Optional[float] = None,
        relaxation: float = 0.7,
        prior_strength: float = 0.0,
        smoothing_strength: float = 0.0,
        use_ml_seed: bool = False,
        ml_seed_threshold: float = 0.6,
        support_threshold: Optional[float] = None,
        support_metric: str = "prior_contribution",
        basis_edges: Optional[np.ndarray] = None,
        aggregate_duplicate_reactions: bool = False,
        uncertainty_method: str = "none",
        n_uncertainty_samples: int = 50,
        uncertainty_seed: Optional[int] = 0,
        default_relative_uncertainty: Optional[float] = None,
        allow_activity_as_rate: bool = False,
        uncertainty_estimator: str = "converged",
        rate_covariance: Optional[np.ndarray] = None,
        require_complete_rate_budget: bool = False,
    ) -> UnfoldingResult:
        """
        Perform spectrum unfolding.

        Parameters
        ----------
        method : str
            Unfolding method: 'GRAVEL' or 'MLEM'
        max_iterations : int
            Maximum iterations
        tolerance : float
            Convergence tolerance (relative change)
        chi2_tolerance : float, optional
            Optional stop when chi-squared per measurement falls below this
            value. Recorded as ``stop_reason='chi2_target'``, never as
            convergence. Disabled by default.
        relaxation : float
            Under-relaxation factor (0-1)
        prior_strength : float
            Geometric pull toward the initial spectrum after each iteration.
            Zero disables this regularization.
        smoothing_strength : float
            Log-space nearest-neighbour smoothing strength applied after each
            iterative update. Zero disables smoothing.
        use_ml_seed : bool
            Use the ML Seed approximation to initialize GRAVEL or RMLE
        ml_seed_threshold : float
            Confidence threshold for accepting the ML seed initializer
        support_threshold : float, optional
            When set, bins with support scores below this threshold are frozen to the
            initial spectrum and only the active subset is iteratively unfolded.
        support_metric : str
            Support score definition: 'prior_contribution' (default) or
            'response_sum'.
        basis_edges : np.ndarray, optional
            Coarse energy boundaries for a few-channel prior-shaped basis solve.
            When provided, the solver updates one coefficient per basis interval
            while preserving the initial spectrum shape inside that interval.
        aggregate_duplicate_reactions : bool
            Combine repeated rows with the same reaction identifier using
            inverse-variance weighting before unfolding. This is useful when
            replicate wires map to identical response functions.
        uncertainty_method : {"none", "monte_carlo"}
            ``"none"`` (default) returns NaN flux uncertainty. ``"monte_carlo"``
            re-solves with Gaussian-resampled rates and reports the sample
            standard deviation per group (rate uncertainty only).
        n_uncertainty_samples : int
            Number of Monte Carlo re-solves.
        uncertainty_seed : int, optional
            Seed for the Monte Carlo resampling.
        default_relative_uncertainty : float, optional
            Relative uncertainty to assume for measurements that carry none.
            Without it, such measurements raise ``ValueError``; the value used
            is recorded in the result metadata.
        allow_activity_as_rate : bool
            Use raw activity (Bq) as the observable for measurements lacking
            mass/timing normalization. Only meaningful for relative spectral
            shape; affected rows are listed in the metadata.

        Returns
        -------
        UnfoldingResult
            Unfolded spectrum and diagnostics
        """
        if len(self.measurements) == 0:
            raise ValueError("No measurements added. Use add_reaction() first.")

        # Build response matrix
        response_matrix, valid_reactions, response_unc = self._build_response_matrix()
        response_matrix = require_nonnegative("response_matrix", response_matrix)

        if len(valid_reactions) == 0:
            raise ValueError("No valid reactions found with cross section data.")

        # Get measured rates and uncertainties
        measured_rates = []
        rate_uncertainties = []
        defaulted_uncertainty_rows: List[str] = []
        activity_proxy_rows: List[str] = []
        for m in self.measurements:
            if m.reaction in valid_reactions:
                try:
                    rate_value = float(m.reaction_rate_per_atom)
                except ValueError as exc:
                    if not allow_activity_as_rate:
                        raise ValueError(
                            f"{exc}. Supply rate_per_atom, or sample_mass_g with "
                            "irradiation timing; pass allow_activity_as_rate=True only "
                            "for relative-shape use of raw activities"
                        ) from exc
                    rate_value = float(m.activity_Bq)
                    activity_proxy_rows.append(m.sample_id or m.reaction)
                measured_rates.append(rate_value)
                rel_uncertainty = float(m.relative_uncertainty)
                if rel_uncertainty <= 0.0:
                    if default_relative_uncertainty is None:
                        raise ValueError(
                            f"Measurement {m.sample_id or m.reaction} has no uncertainty; "
                            "supply one or pass default_relative_uncertainty explicitly"
                        )
                    rel_uncertainty = float(default_relative_uncertainty)
                    defaulted_uncertainty_rows.append(m.sample_id or m.reaction)
                rate_uncertainties.append(rate_value * rel_uncertainty)

        measured_rates = require_nonnegative("measured_rates", measured_rates).reshape(-1)
        rate_uncertainties = require_nonnegative(
            "rate_uncertainties",
            rate_uncertainties,
        ).reshape(-1)

        selected = [m for m in self.measurements if m.reaction in valid_reactions]
        budgets = [m.rate_uncertainty_budget for m in selected]
        covariance_note = "diagonal reported rate errors; component budget unavailable"
        observation_covariance = None
        if any(b is not None for b in budgets):
            if not all(b is not None for b in budgets):
                raise ValueError("Supply a rate budget for every observation, or none")
            for m, budget, rate in zip(selected, budgets, measured_rates):
                identity = (m.response_spec.observation_id if m.response_spec is not None
                            else m.sample_id)
                if budget.row_id != identity or budget.rate != rate:
                    raise ValueError("Rate budget must bind the current observation identity and rate")
            observation_covariance = budget_covariance(budgets, require_complete=require_complete_rate_budget)
            covariance_note = ("source/component coverage complete; scientific admission separate"
                               if all(b.complete for b in budgets) else "incomplete component budget; diagnostic covariance")
        elif require_complete_rate_budget:
            raise ValueError("A complete source/component rate budget is required for every observation")
        if rate_covariance is not None:
            supplied = covariance_matrix(rate_covariance, len(measured_rates), "rate_covariance")
            if observation_covariance is not None and not np.allclose(supplied, observation_covariance, rtol=1e-12, atol=0.):
                raise ValueError("Explicit rate covariance disagrees with component budgets")
            observation_covariance = supplied
            if all(b is None for b in budgets):
                covariance_note = "caller-supplied covariance; component completeness unqualified"
        if observation_covariance is not None:
            if not np.allclose(np.sqrt(np.diag(observation_covariance)), rate_uncertainties, rtol=1e-12, atol=0.):
                raise ValueError("Rate covariance diagonal must match reported rate uncertainties")

        duplicate_metadata: Dict[str, Any] = {
            "applied": False,
            "original_rows": int(len(valid_reactions)),
            "aggregated_rows": int(len(valid_reactions)),
            "reaction_counts": {
                str(reaction): 1 for reaction in valid_reactions
            },
            "memberships": [
                {"row_indices": [i], "observation_ids": [
                    m.response_spec.observation_id if m.response_spec is not None
                    else f"{m.sample_id or m.reaction}:{i}"]}
                for i, m in enumerate(self.measurements) if m.reaction in valid_reactions
            ],
        }
        if aggregate_duplicate_reactions:
            aggregation_payload = self._aggregate_duplicate_reaction_rows(
                response_matrix,
                valid_reactions,
                measured_rates,
                rate_uncertainties,
                response_unc,
                row_keys=[
                    m.row_key for m in self.measurements if m.reaction in valid_reactions
                ],
                observation_ids=[member["observation_ids"][0]
                                 for member in duplicate_metadata["memberships"]],
                uncertainty_models=(
                    [row.get("uncertainty_components_barn") for row in self._response_row_metadata]
                    if len(self._response_row_metadata) == len(valid_reactions) else None
                ),
                measurement_covariance=observation_covariance,
            )
            response_matrix = require_nonnegative(
                "response_matrix",
                aggregation_payload["response"],
            )
            valid_reactions = list(aggregation_payload["reactions"])
            measured_rates = require_nonnegative(
                "measured_rates",
                aggregation_payload["measurements"],
            ).reshape(-1)
            rate_uncertainties = require_nonnegative(
                "rate_uncertainties",
                aggregation_payload["uncertainties"],
            ).reshape(-1)
            response_unc = aggregation_payload["response_uncertainties"]
            duplicate_metadata = dict(aggregation_payload["metadata"])
            observation_covariance = aggregation_payload["measurement_covariance"]

        # Prepare initial guess
        if self.initial_flux is not None:
            initial = self.initial_flux.tolist()
        else:
            # Default: flat spectrum scaled to match measurements
            avg_rate = np.mean(measured_rates)
            avg_xs = np.mean(response_matrix)
            initial = [
                avg_rate / (avg_xs * self.n_groups) if avg_xs > 0 else 1.0
            ] * self.n_groups
        initial_array = require_nonnegative("initial_flux", initial).reshape(-1)

        basis_matrix: Optional[np.ndarray] = None
        basis_metadata: Dict[str, Any] = {
            "basis_mode": "native",
            "basis_edges": [],
            "basis_groups": int(self.n_groups),
        }
        full_solver_initial = initial_array
        solver_base_response = response_matrix
        if basis_edges is not None:
            basis_payload = self._build_prior_shape_basis(initial_array, basis_edges)
            basis_matrix = np.asarray(basis_payload["basis_matrix"], dtype=float)
            solver_base_response = response_matrix @ basis_matrix
            full_solver_initial = np.ones(basis_matrix.shape[1], dtype=float)
            basis_metadata = {
                "basis_mode": "prior_shape",
                "basis_edges": basis_payload["basis_edges"].tolist(),
                "basis_groups": int(basis_payload["n_basis_groups"]),
            }

        support_problem = self._prepare_support_filtered_problem(
            solver_base_response,
            measured_rates,
            rate_uncertainties,
            full_solver_initial,
            support_threshold=support_threshold,
            support_metric=support_metric,
        )
        solver_response_matrix = require_nonnegative(
            "solver_response_matrix",
            support_problem["response"],
        )
        solver_measurements = require_nonnegative(
            "solver_measurements",
            support_problem["measurements"],
        ).reshape(-1)
        solver_rate_uncertainties = require_nonnegative(
            "solver_rate_uncertainties",
            support_problem["uncertainties"],
        ).reshape(-1)
        solver_initial = require_nonnegative(
            "solver_initial",
            support_problem["initial_flux"],
        ).reshape(-1)
        active_mask = np.asarray(support_problem["active_mask"], dtype=bool)
        support_scores = np.asarray(support_problem["support_scores"], dtype=float)
        fixed_prediction = np.asarray(support_problem["fixed_prediction"], dtype=float)

        if self.verbose:
            print(f"\nStarting {method} unfolding:")
            print(f"  Reactions: {len(valid_reactions)}")
            print(f"  Energy groups: {self.n_groups}")
            print(f"  Initial guess: {self.initial_guess_source}")
            if duplicate_metadata["applied"]:
                print(
                    "  Duplicate aggregation: "
                    f"{duplicate_metadata['original_rows']} -> {duplicate_metadata['aggregated_rows']} rows"
                )
            if not np.all(active_mask):
                print(
                    f"  Active groups: {int(np.count_nonzero(active_mask))}/{len(active_mask)} "
                    f"(metric={support_metric}, threshold={support_threshold:.3e})"
                )

        # Run unfolding
        seed_metadata: Dict[str, Any] = {}
        method_key = method.upper()
        if method_key not in {"GRAVEL", "MLEM", "MAXED", "ML_SEED", "RMLE"}:
            raise ValueError(
                f"Unknown method: {method}. Use 'GRAVEL', 'MLEM', 'MAXED', 'RMLE', or 'ML_SEED'."
            )
        if method_key == "GRAVEL" and use_ml_seed:
            seed_result = MLSeedUnfolder().unfold(
                solver_measurements,
                solver_response_matrix,
                initial_flux=solver_initial,
                measurement_uncertainty=solver_rate_uncertainties,
                confidence_threshold=ml_seed_threshold,
            )
            seed_metadata = {
                "seed_with_ml": True,
                "seed_accepted": bool(
                    seed_result.parameters_used.get("accepted", False)
                ),
                "seed_confidence_score": float(
                    seed_result.parameters_used.get("confidence_score", 0.0)
                ),
                "seed_backend": str(
                    seed_result.parameters_used.get("backend", "")
                ),
            }
            if bool(seed_result.parameters_used.get("accepted", False)):
                solver_initial = np.asarray(seed_result.flux, dtype=float)

        def _solve(measurement_vector: np.ndarray, verbose: bool):
            if method_key == "GRAVEL":
                return gravel(
                    response=solver_response_matrix.tolist(),
                    measurements=measurement_vector.tolist(),
                    initial_flux=solver_initial.tolist(),
                    measurement_uncertainty=solver_rate_uncertainties.tolist(),
                    max_iters=max_iterations,
                    tolerance=tolerance,
                    chi2_tolerance=chi2_tolerance,
                    relaxation=relaxation,
                    prior_strength=prior_strength,
                    smoothing_strength=smoothing_strength,
                    verbose=verbose,
                )
            if method_key == "MLEM":
                return mlem(
                    response=solver_response_matrix.tolist(),
                    measurements=measurement_vector.tolist(),
                    initial_flux=solver_initial.tolist(),
                    measurement_uncertainty=solver_rate_uncertainties.tolist(),
                    max_iters=max_iterations,
                    tolerance=tolerance,
                    chi2_tolerance=chi2_tolerance,
                    relaxation=relaxation,
                    prior_strength=prior_strength,
                    smoothing_strength=smoothing_strength,
                    verbose=verbose,
                )
            if method_key == "MAXED":
                return MaxedUnfolder(max_iterations=max_iterations).unfold(
                    measurement_vector,
                    solver_response_matrix,
                    initial_flux=solver_initial,
                    measurement_uncertainty=solver_rate_uncertainties,
                )
            if method_key == "ML_SEED":
                return MLSeedUnfolder().unfold(
                    measurement_vector,
                    solver_response_matrix,
                    initial_flux=solver_initial,
                    measurement_uncertainty=solver_rate_uncertainties,
                    confidence_threshold=ml_seed_threshold,
                )
            return RMLEUnfolder(
                max_iterations=max_iterations,
                tolerance=tolerance,
            ).unfold(
                measurement_vector,
                solver_response_matrix,
                initial_flux=solver_initial,
                measurement_uncertainty=solver_rate_uncertainties,
                seed_with_ml=use_ml_seed,
                confidence_threshold=ml_seed_threshold,
            )

        def _full_flux(solver_flux_vector) -> np.ndarray:
            solver_flux_vector = np.asarray(solver_flux_vector, dtype=float)
            if np.all(active_mask):
                state = solver_flux_vector
            else:
                state = full_solver_initial.copy()
                state[active_mask] = solver_flux_vector
            return state if basis_matrix is None else basis_matrix @ state

        result = _solve(solver_measurements, self.verbose)
        flux_array = _full_flux(result.flux)
        predicted_rates = response_matrix @ flux_array

        # Flux uncertainty must come from the estimator actually used. The
        # ridge pseudo-inverse is unrelated to GRAVEL/MLEM and is not reported.
        uncertainty_metadata: Dict[str, Any] = {
            "flux_uncertainty_method": uncertainty_method,
            "rate_covariance_qualification": covariance_note,
            "iterative_fit_covariance": "diagonal objective; full covariance used for resampling/aggregation only",
            "rate_covariance": None if observation_covariance is None else observation_covariance.tolist(),
            "rate_budgets": [b.as_row() for b in budgets if b is not None],
            "normalization_abundance": [
                {"sample_id": m.sample_id, "supplied": m.isotope_abundance,
                 "effective": m.effective_isotope_abundance if m.sample_mass_g is not None else None,
                 "basis": "explicit" if m.isotope_abundance is not None else "natural_lookup"}
                for m in selected],
        }
        if uncertainty_method == "none":
            flux_uncertainty = np.full(flux_array.shape, np.nan)
            uncertainty_metadata["flux_uncertainty_note"] = (
                "not estimated; use uncertainty_method='monte_carlo'"
            )
        elif uncertainty_method == "monte_carlo":
            if n_uncertainty_samples < 2:
                raise ValueError("n_uncertainty_samples must be at least 2")
            rng = np.random.default_rng(uncertainty_seed)
            tiny = np.finfo(float).tiny
            samples = []
            statuses = []
            if uncertainty_estimator not in {"converged", "capped"}:
                raise ValueError("uncertainty_estimator must be 'converged' or 'capped'")
            factor = None if observation_covariance is None else covariance_factor(observation_covariance)
            for draw in range(n_uncertainty_samples):
                perturbed = (rng.normal(solver_measurements, solver_rate_uncertainties) if factor is None else
                             solver_measurements + factor @ rng.normal(size=len(solver_measurements)))
                status = {"draw": draw, "converged": False, "finite": False,
                          "stop_reason": "exception", "iterations": None,
                          "clipped_rate_rows": int(np.count_nonzero(perturbed < tiny))}
                try:
                    sample_result = _solve(np.maximum(perturbed, tiny), False)
                    sample_flux = _full_flux(sample_result.flux)
                    valid = (sample_flux.shape == flux_array.shape and np.all(np.isfinite(sample_flux))
                             and np.all(sample_flux >= 0))
                    status.update(converged=bool(getattr(sample_result, "converged", False)), finite=bool(valid),
                                  stop_reason=getattr(sample_result, "stop_reason", "unspecified"),
                                  iterations=int(sample_result.iterations))
                    if valid:
                        samples.append(sample_flux)
                except (ValueError, np.linalg.LinAlgError, FloatingPointError) as exc:
                    status["error"] = str(exc)
                statuses.append(status)
            finite_draws = sum(s["finite"] for s in statuses)
            converged_draws = sum(s["finite"] and s["converged"] for s in statuses)
            qualifies = (finite_draws == n_uncertainty_samples and
                         np.all(np.isfinite(flux_array)) and np.all(flux_array >= 0) and
                         (uncertainty_estimator == "capped" or
                          (result.converged and converged_draws == n_uncertainty_samples)))
            ensemble_error = None
            flux_covariance = None
            if qualifies:
                # Finite draws can still overflow the derived second moment.
                with np.errstate(over="ignore", invalid="ignore", divide="ignore"):
                    flux_covariance = np.atleast_2d(np.cov(np.asarray(samples), rowvar=False, ddof=1))
                    candidate_uncertainty = np.sqrt(np.maximum(np.diag(flux_covariance), 0.))
                if not (np.all(np.isfinite(flux_covariance)) and np.all(np.isfinite(candidate_uncertainty))):
                    qualifies = False
                    ensemble_error = "nonfinite sample covariance or standard deviation"
                    flux_covariance = None
            flux_uncertainty = (candidate_uncertainty if qualifies else
                                np.full(flux_array.shape, np.nan))
            stop_counts = {}
            for status in statuses:
                stop_counts[status["stop_reason"]] = stop_counts.get(status["stop_reason"], 0) + 1
            uncertainty_metadata.update(
                {
                    "flux_uncertainty_samples": int(n_uncertainty_samples),
                    "flux_uncertainty_seed": uncertainty_seed,
                    "flux_uncertainty_estimator": uncertainty_estimator,
                    "flux_uncertainty_qualification": ("capped_diagnostic" if uncertainty_estimator == "capped"
                                                       else "converged_conditional") if qualifies else "unavailable",
                    "flux_uncertainty_attempted": n_uncertainty_samples,
                    "flux_uncertainty_finite_draws": finite_draws,
                    "flux_uncertainty_converged_draws": converged_draws,
                    "flux_uncertainty_usable": n_uncertainty_samples if qualifies else 0,
                    "flux_uncertainty_ensemble_error": ensemble_error,
                    "flux_uncertainty_draw_status": statuses,
                    "flux_uncertainty_stop_counts": stop_counts,
                    "flux_uncertainty_main_converged": bool(result.converged),
                    "flux_uncertainty_covariance": None if flux_covariance is None else flux_covariance.tolist(),
                    "flux_uncertainty_note": (
                        "standard deviation over re-solves with Gaussian-resampled "
                        "rates using the recorded covariance; response and prior uncertainty not included. "
                        "No failed draws are selected away; any invalid draw makes the ensemble unavailable. "
                        "Converged estimator requires main and all draws converged; capped estimator is explicit diagnostic."
                    ),
                }
            )
        else:
            raise ValueError("uncertainty_method must be 'none' or 'monte_carlo'")

        if self.verbose:
            print(f"\nUnfolding complete:")
            print(f"  Iterations: {result.iterations}")
            print(f"  Converged: {result.converged}")
            print(f"  Chi²/measurement: {result.chi_squared:.4f}")
            print(f"  Stop reason: {getattr(result, 'stop_reason', 'unspecified')}")

        return UnfoldingResult(
            energy_edges=self.energy_edges.copy(),
            flux=flux_array,
            flux_uncertainty=flux_uncertainty,
            reactions_used=list(valid_reactions),
            response_matrix=response_matrix.copy(),
            measured_rates=measured_rates,
            predicted_rates=predicted_rates,
            chi_squared=result.chi_squared,
            iterations=result.iterations,
            converged=result.converged,
            method=method.upper(),
            initial_guess_source=self.initial_guess_source,
            metadata=merge_flux_diagnostics(
                {
                    **dict(getattr(result, "parameters_used", {})),
                    **dict(getattr(result, "diagnostics", {})),
                    **seed_metadata,
                    "chi2_history": list(getattr(result, "chi_squared_history", []))
                    or list(getattr(result, "convergence_history", [])),
                    "final_residuals": getattr(result, "final_residuals", [])
                    or list(getattr(result, "residuals", [])),
                    "support_mask_applied": bool(not np.all(active_mask)),
                    "support_metric": support_metric,
                    "support_threshold": support_threshold,
                    "support_mask_active_bins": int(np.count_nonzero(active_mask)),
                    "support_mask_total_bins": int(len(active_mask)),
                    "support_mask_fixed_prediction": fixed_prediction.tolist(),
                    "support_scores_max": float(np.max(support_scores))
                    if support_scores.size
                    else 0.0,
                    "aggregate_duplicate_reactions": bool(aggregate_duplicate_reactions),
                    "duplicate_reaction_aggregation_applied": bool(
                        duplicate_metadata["applied"]
                    ),
                    "duplicate_reaction_original_rows": int(
                        duplicate_metadata["original_rows"]
                    ),
                    "duplicate_reaction_aggregated_rows": int(
                        duplicate_metadata["aggregated_rows"]
                    ),
                    "duplicate_reaction_counts": dict(
                        duplicate_metadata["reaction_counts"]
                    ),
                    **basis_metadata,
                    **uncertainty_metadata,
                    "response_rows": deepcopy(getattr(self, "_response_row_metadata", [])),
                    "duplicate_reaction_memberships": duplicate_metadata.get("memberships", []),
                    "default_relative_uncertainty": default_relative_uncertainty,
                    "rows_with_default_uncertainty": defaulted_uncertainty_rows,
                    "activity_used_as_rate_rows": activity_proxy_rows,
                    "stop_reason": getattr(result, "stop_reason", "unspecified"),
                    "tolerance": tolerance,
                    "chi2_tolerance": chi2_tolerance,
                    "relaxation": relaxation,
                    "prior_strength": prior_strength,
                    "smoothing_strength": smoothing_strength,
                },
                flux_array,
            ),
        )

    def compare_with_mcnp(
        self,
        mcnp_spectrum: Union[str, Path, np.ndarray],
        unfolded_result: UnfoldingResult,
    ) -> Dict[str, Any]:
        """
        Compare unfolded spectrum with MCNP reference.

        Parameters
        ----------
        mcnp_spectrum : str, Path, or np.ndarray
            MCNP spectrum (file path or array)
        unfolded_result : UnfoldingResult
            Unfolded spectrum

        Returns
        -------
        Dict
            Comparison metrics
        """
        if isinstance(mcnp_spectrum, (str, Path)):
            # Load from file
            self.set_mcnp_initial_guess(mcnp_spectrum)
            mcnp_flux = self.initial_flux
        else:
            mcnp_flux = np.array(mcnp_spectrum)

        unfolded_flux = unfolded_result.flux

        # Normalize for comparison
        mcnp_norm = mcnp_flux / np.sum(mcnp_flux)
        unfolded_norm = unfolded_flux / np.sum(unfolded_flux)

        # Calculate metrics
        ratio = np.where(mcnp_norm > 1e-30, unfolded_norm / mcnp_norm, 1.0)
        residual = unfolded_norm - mcnp_norm

        return {
            "mcnp_flux": mcnp_flux,
            "mcnp_normalized": mcnp_norm,
            "unfolded_normalized": unfolded_norm,
            "ratio": ratio,
            "residual": residual,
            "mean_ratio": np.mean(ratio),
            "std_ratio": np.std(ratio),
            "max_deviation": np.max(np.abs(residual)),
            "rms_deviation": np.sqrt(np.mean(residual**2)),
        }


# =============================================================================
# Convenience Functions
# =============================================================================


def quick_unfold(
    reactions: Dict[str, float],
    uncertainties: Optional[Dict[str, float]] = None,
    initial_spectrum: Optional[np.ndarray] = None,
    method: str = "GRAVEL",
    energy_structure: str = "flux_wire",
    verbose: bool = True,
    use_ml_seed: bool = False,
    ml_seed_threshold: float = 0.6,
) -> UnfoldingResult:
    """
    Quick spectrum unfolding from dictionary of reactions.

    Parameters
    ----------
    reactions : Dict[str, float]
        Dictionary mapping reaction -> activity (Bq)
    uncertainties : Dict[str, float], optional
        Dictionary mapping reaction -> uncertainty (Bq)
    initial_spectrum : np.ndarray, optional
        Initial flux guess
    method : str
        Unfolding method
    energy_structure : str
        Energy group structure
    verbose : bool
        Print status
    use_ml_seed : bool
        Use the ML Seed approximation to initialize GRAVEL or RMLE
    ml_seed_threshold : float
        Confidence threshold for accepting the ML seed initializer

    Returns
    -------
    UnfoldingResult
        Unfolded spectrum

    Examples
    --------
    >>> result = quick_unfold({
    ...     "Ti-46(n,p)Sc-46": 1.23e5,
    ...     "Ni-58(n,p)Co-58": 4.56e5,
    ...     "Co-59(n,g)Co-60": 7.89e3,
    ... })
    """
    if uncertainties is None:
        uncertainties = {rxn: 0.1 * act for rxn, act in reactions.items()}

    unfolder = SpectrumUnfolder(
        energy_structure=energy_structure,
        verbose=verbose,
    )

    for rxn, activity in reactions.items():
        unfolder.add_reaction(
            reaction=rxn,
            activity_Bq=activity,
            uncertainty_Bq=uncertainties.get(rxn, activity * 0.1),
        )

    if initial_spectrum is not None:
        unfolder.set_initial_guess(initial_spectrum, source="user")

    # Raw activities are the observable here: the result is a relative
    # spectral shape only (see UnfoldingResult.metadata).
    return unfolder.unfold(
        method=method,
        use_ml_seed=use_ml_seed,
        ml_seed_threshold=ml_seed_threshold,
        allow_activity_as_rate=True,
    )


def build_flux_wire_response_matrix(
    reactions: Optional[List[str]] = None,
    energy_structure: str = "flux_wire",
    custom_edges: Optional[np.ndarray] = None,
) -> Tuple[np.ndarray, np.ndarray, List[str]]:
    """
    Build response matrix for standard flux wire reactions.

    Parameters
    ----------
    reactions : List[str], optional
        Reactions to include. If None, uses standard set.
    energy_structure : str
        Energy group structure
    custom_edges : np.ndarray, optional
        Custom energy edges

    Returns
    -------
    response_matrix : np.ndarray
        Response matrix (n_reactions x n_groups)
    energy_edges : np.ndarray
        Energy group edges (eV)
    reactions : List[str]
        Reaction names
    """
    if reactions is None:
        reactions = [
            "Ti-46(n,p)Sc-46",
            "Ti-47(n,p)Sc-47",
            "Ti-48(n,p)Sc-48",
            "Ni-58(n,p)Co-58",
            "Fe-56(n,p)Mn-56",
            "In-115(n,n')In-115m",
            "Al-27(n,a)Na-24",
            "Co-59(n,g)Co-60",
            "Sc-45(n,g)Sc-46",
            "Fe-58(n,g)Fe-59",
            "Cu-63(n,g)Cu-64",
        ]

    if custom_edges is not None:
        energy_edges = custom_edges
    elif energy_structure == "flux_wire":
        energy_edges = get_flux_wire_energy_groups()
    elif energy_structure == "activation":
        energy_edges = get_activation_energy_groups()
    else:
        db = IRDFFDatabase()
        energy_edges = db.get_energy_grid(energy_structure)

    response, valid_reactions, _ = build_response_matrix(
        reactions=reactions,
        energy_edges=energy_edges,
        verbose=False,
    )

    return response, energy_edges, valid_reactions
