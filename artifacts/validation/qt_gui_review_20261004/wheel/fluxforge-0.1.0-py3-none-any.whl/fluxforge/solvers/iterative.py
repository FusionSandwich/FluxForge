"""Iterative unfolding algorithms (GRAVEL and MLEM).

These implement the standard iterative spectrum unfolding methods:
- GRAVEL: Log-space multiplicative update (SAND-II variant)
- MLEM: Maximum-Likelihood Expectation Maximization

Enhanced with:
- Relaxation/damping for improved convergence
- Chi-squared convergence monitoring
- Support for MCNP spectrum as initial guess
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Any, List, Optional, Tuple

from fluxforge.core.unfolding_diagnostics import merge_flux_diagnostics
from fluxforge.core.unfolding_inputs import require_nonnegative
from fluxforge.core.linalg import Matrix, Vector, elementwise_maximum, matmul


# Small enough to preserve reference-implementation parity without hitting zero.
_ITERATIVE_POSITIVE_FLOOR = 1e-100

CHI_SQUARED_DEFINITION = (
    "sum(((y_i - (R phi)_i) / sigma_i)^2) / n_measurements; descriptive, not "
    "corrected for fitted degrees of freedom or regularization"
)


@dataclass
class IterativeSolution:
    """Container for iterative solver results.

    ``converged`` reports numerical convergence of the iteration only (relative
    change or ddJ criterion). ``chi_squared`` is the postfit chi-squared per
    measurement (see ``CHI_SQUARED_DEFINITION``); for underdetermined problems it
    is not a reduced chi-squared. ``stop_reason`` is one of ``"converged"``,
    ``"chi2_target"`` or ``"max_iterations"``.
    """

    flux: Vector
    history: List[Vector]
    iterations: int
    converged: bool
    chi_squared: float = 0.0
    chi_squared_history: List[float] = field(default_factory=list)
    final_residuals: Optional[Vector] = None
    diagnostics: dict[str, Any] = field(default_factory=dict)
    chi_squared_total: Optional[float] = None
    n_measurements: Optional[int] = None
    stop_reason: str = "unspecified"

    def __post_init__(self) -> None:
        self.diagnostics = merge_flux_diagnostics(self.diagnostics, self.flux)
        self.diagnostics.setdefault("chi_squared_definition", CHI_SQUARED_DEFINITION)
        self.diagnostics.setdefault("stop_reason", self.stop_reason)


def _default_flux(n_groups: int, scale: float = 1.0) -> Vector:
    return [scale for _ in range(n_groups)]


def _validate_iterative_inputs(
    response: Matrix,
    measurements: Vector,
    initial_flux: Optional[Vector] = None,
    measurement_uncertainty: Optional[Vector] = None,
) -> tuple[Matrix, Vector, Optional[Vector], Optional[Vector]]:
    """Normalize iterative unfolding inputs using shared nonnegative guards."""

    response_array = require_nonnegative("response", response)
    if response_array.ndim != 2:
        raise ValueError("response must be a 2-D array")

    measurements_array = require_nonnegative("measurements", measurements).reshape(-1)
    if response_array.shape[0] != measurements_array.size:
        raise ValueError("response row count must match the measurements length")

    initial_array = None
    if initial_flux is not None:
        initial_array = require_nonnegative("initial_flux", initial_flux).reshape(-1)
        if initial_array.size != response_array.shape[1]:
            raise ValueError(
                "initial_flux length must match the response column count"
            )

    uncertainty_array = None
    if measurement_uncertainty is not None:
        uncertainty_array = require_nonnegative(
            "measurement_uncertainty",
            measurement_uncertainty,
        ).reshape(-1)
        if uncertainty_array.size != measurements_array.size:
            raise ValueError(
                "measurement_uncertainty length must match the measurements length"
            )

    return (
        response_array.astype(float).tolist(),
        measurements_array.astype(float).tolist(),
        None if initial_array is None else initial_array.astype(float).tolist(),
        None
        if uncertainty_array is None
        else uncertainty_array.astype(float).tolist(),
    )


def _compute_chi_squared(
    response: Matrix,
    flux: Vector,
    measurements: Vector,
    uncertainties: Optional[Vector] = None,
    floor: float = 1e-20,
) -> Tuple[float, Vector]:
    """Compute chi-squared and residuals for current flux estimate."""
    predicted = matmul(response, flux)
    predicted = [max(p, floor) for p in predicted]

    residuals = []
    chi2 = 0.0
    for i, (m, p) in enumerate(zip(measurements, predicted)):
        # Without supplied uncertainties the solvers assume Poisson variance.
        unc = uncertainties[i] if uncertainties else math.sqrt(max(m, floor))
        if unc > 0:
            r = (m - p) / unc
            residuals.append(r)
            chi2 += r * r
        else:
            residuals.append(0.0)

    return chi2, residuals


def _blend_with_reference(
    flux: Vector,
    reference_flux: Optional[Vector],
    strength: float,
    floor: float,
) -> Vector:
    """Geometrically blend one iterate toward a positive reference spectrum."""
    if reference_flux is None or strength <= 0.0:
        return flux

    blended: Vector = []
    for current, reference in zip(flux, reference_flux):
        current_value = max(current, floor)
        reference_value = max(reference, floor)
        log_value = (1.0 - strength) * math.log(current_value) + strength * math.log(
            reference_value
        )
        blended.append(max(math.exp(log_value), floor))
    return blended


def _smooth_log_flux(flux: Vector, strength: float, floor: float) -> Vector:
    """Apply a light nearest-neighbour smoothness prior in log-space."""
    if strength <= 0.0 or len(flux) < 3:
        return flux

    log_flux = [math.log(max(value, floor)) for value in flux]
    smoothed = log_flux[:]
    for index in range(1, len(log_flux) - 1):
        neighbor_mean = 0.5 * (log_flux[index - 1] + log_flux[index + 1])
        smoothed[index] = (1.0 - strength) * log_flux[index] + strength * neighbor_mean

    smoothed_flux = [max(math.exp(value), floor) for value in smoothed]
    original_total = sum(max(value, floor) for value in flux)
    smoothed_total = sum(smoothed_flux)
    if original_total > 0.0 and smoothed_total > 0.0:
        scale = original_total / smoothed_total
        smoothed_flux = [max(value * scale, floor) for value in smoothed_flux]
    return smoothed_flux


def _stabilize_iterative_flux(
    flux: Vector,
    reference_flux: Optional[Vector],
    prior_strength: float,
    smoothing_strength: float,
    floor: float,
) -> Vector:
    """Apply opt-in regularization to one iterative solver update."""
    stabilized = _blend_with_reference(flux, reference_flux, prior_strength, floor)
    stabilized = _smooth_log_flux(stabilized, smoothing_strength, floor)
    return [max(value, floor) for value in stabilized]


def gravel(
    response: Matrix,
    measurements: Vector,
    initial_flux: Optional[Vector] = None,
    measurement_uncertainty: Optional[Vector] = None,
    max_iters: int = 1000,
    tolerance: float = 1e-4,
    chi2_tolerance: Optional[float] = None,
    floor: float = _ITERATIVE_POSITIVE_FLOOR,
    relaxation: float = 0.7,
    prior_strength: float = 0.0,
    smoothing_strength: float = 0.0,
    convergence_mode: str = "relative",  # "relative" or "ddJ" (Neutron-Unfolding style)
    verbose: bool = False,
) -> IterativeSolution:
    """GRAVEL algorithm (log-space SAND-II variant) for spectrum unfolding.

    Args:
        response: Response matrix R_{i,g}.
        measurements: Measured reaction rates y_i.
        initial_flux: Starting flux guess. Defaults to uniform.
        measurement_uncertainty: Optional 1-sigma uncertainties on y_i. Rows are
            weighted by (y_i / sigma_i)^2 as in UMG GRAVEL; without them,
            Poisson variance (weight y_i) is assumed.
        max_iters: Maximum iterations to perform.
        tolerance: Relative max change threshold for convergence.
        chi2_tolerance: Optional stop when chi2 per measurement falls below this
            value. Records ``stop_reason='chi2_target'``; never sets ``converged``.
        floor: Minimum flux/prediction value to avoid divide-by-zero.
        relaxation: Under-relaxation factor (0-1). Lower = more stable, slower.
        prior_strength: Geometric pull toward the initial spectrum after each
            iteration. Zero disables this regularization.
        smoothing_strength: Log-space nearest-neighbour smoothing strength
            applied after each update. Zero disables smoothing.
        convergence_mode: "relative" (default) uses max relative flux change,
            "ddJ" uses the Neutron-Unfolding style second-derivative criterion.
        verbose: Print convergence progress.
    """

    response, measurements, initial_flux, measurement_uncertainty = (
        _validate_iterative_inputs(
            response,
            measurements,
            initial_flux=initial_flux,
            measurement_uncertainty=measurement_uncertainty,
        )
    )

    n_groups = len(response[0])
    n_meas = len(measurements)

    # Initialize flux
    if initial_flux is not None:
        phi = initial_flux[:]
    else:
        # Better default: scale to match average measurement
        avg_meas = sum(measurements) / len(measurements)
        phi = _default_flux(n_groups, scale=avg_meas / n_groups)

    phi = elementwise_maximum(phi, floor)
    regularization_reference = phi[:]

    # GRAVEL row factor (Matzke, UMG): W_ig = (y_i / sigma_i)^2 R_ig phi_g / p_i.
    # Without uncertainties, Poisson variance sigma_i^2 = y_i gives factor y_i
    # (the Neutron-Unfolding reference form). Both are invariant to the units
    # chosen for any individual row.
    row_factors = (
        [(m / u) ** 2 if u > 0 else 0.0 for m, u in zip(measurements, measurement_uncertainty)]
        if measurement_uncertainty
        else list(measurements)
    )

    history: List[Vector] = [phi[:]]
    chi2_history: List[float] = []
    converged = False
    stop_reason = "max_iterations"
    ddj_indices = [idx for idx, value in enumerate(measurements) if value > 0.0]
    J_prev = 0.0
    dJ_prev = 1.0

    for it in range(1, max_iters + 1):
        predicted = matmul(response, phi)
        predicted = [max(p, floor) for p in predicted]

        # Compute chi-squared
        chi2, residuals = _compute_chi_squared(
            response, phi, measurements, measurement_uncertainty, floor
        )
        chi2_per_meas = chi2 / max(n_meas, 1)
        chi2_history.append(chi2_per_meas)

        if verbose and it % 100 == 0:
            print(f"  GRAVEL iter {it}: chi2/n = {chi2_per_meas:.4f}")

        if convergence_mode == "ddJ":
            ddj_predicted = [predicted[idx] for idx in ddj_indices]
            ddj_measurements = [measurements[idx] for idx in ddj_indices]
            if ddj_predicted:
                J = sum(
                    (p - m) * (p - m)
                    for p, m in zip(ddj_predicted, ddj_measurements)
                ) / max(sum(ddj_predicted), floor)
            else:
                J = 0.0
            dJ = J_prev - J
            ddJ = abs(dJ - dJ_prev)
            J_prev = J
            dJ_prev = dJ

        # Compute log ratios of measurements to predictions
        log_ratios = [
            math.log(max(m / p, floor)) for m, p in zip(measurements, predicted)
        ]

        updated: Vector = []
        max_rel_change = 0.0
        for g in range(n_groups):
            num = 0.0
            den = 0.0
            for i in range(n_meas):
                if measurements[i] > 0 and predicted[i] > floor:
                    W_ig = row_factors[i] * response[i][g] * phi[g] / predicted[i]
                    num += W_ig * log_ratios[i]
                    den += W_ig

            if den <= floor:
                updated.append(phi[g])
                continue

            # Calculate update with relaxation
            factor = math.exp(num / den)
            target_phi = phi[g] * factor
            new_phi = phi[g] + relaxation * (target_phi - phi[g])
            new_phi = max(new_phi, floor)

            max_rel_change = max(
                max_rel_change, abs(new_phi - phi[g]) / max(phi[g], floor)
            )
            updated.append(new_phi)

        phi = _stabilize_iterative_flux(
            updated,
            reference_flux=regularization_reference,
            prior_strength=prior_strength,
            smoothing_strength=smoothing_strength,
            floor=floor,
        )
        history.append(phi[:])

        # Check convergence criteria
        if convergence_mode == "ddJ" and ddJ < tolerance:
            converged = True
            stop_reason = "converged"
            if verbose:
                print(
                    f"  GRAVEL converged at iter {it}: ddJ = {ddJ:.2e}, chi2/n = {chi2_per_meas:.4f}"
                )
            break

        if convergence_mode == "relative" and max_rel_change < tolerance:
            converged = True
            stop_reason = "converged"
            if verbose:
                print(
                    f"  GRAVEL converged at iter {it}: rel_change = {max_rel_change:.2e}, chi2/n = {chi2_per_meas:.4f}"
                )
            break

        if chi2_tolerance is not None and chi2_per_meas < chi2_tolerance:
            # A small residual is a stopping target, not numerical convergence.
            stop_reason = "chi2_target"
            if verbose:
                print(f"  GRAVEL stopped at chi2 target, iter {it}: chi2/n = {chi2_per_meas:.4f}")
            break

    final_chi2, final_residuals = _compute_chi_squared(
        response, phi, measurements, measurement_uncertainty, floor
    )

    return IterativeSolution(
        flux=phi,
        history=history,
        iterations=it if "it" in dir() else max_iters,
        converged=converged,
        chi_squared=final_chi2 / max(n_meas, 1),
        chi_squared_total=final_chi2,
        n_measurements=n_meas,
        stop_reason=stop_reason,
        chi_squared_history=chi2_history,
        final_residuals=final_residuals,
        diagnostics=merge_flux_diagnostics(
            None,
            phi,
            negative_policy="floor_clamped",
            nonnegativity_enforced=True,
        ),
    )


def mlem(
    response: Matrix,
    measurements: Vector,
    initial_flux: Optional[Vector] = None,
    measurement_uncertainty: Optional[Vector] = None,
    max_iters: int = 1000,
    tolerance: float = 1e-4,
    chi2_tolerance: Optional[float] = None,
    floor: float = _ITERATIVE_POSITIVE_FLOOR,
    relaxation: float = 0.8,
    prior_strength: float = 0.0,
    smoothing_strength: float = 0.0,
    convergence_mode: str = "relative",  # "relative" or "ddJ" (Neutron-Unfolding style)
    verbose: bool = False,
) -> IterativeSolution:
    """Maximum-likelihood expectation maximization (MLEM) unfolding.

    Args:
        response: Response matrix R_{i,g}.
        measurements: Measured reaction rates y_i.
        initial_flux: Starting flux guess. Defaults to uniform.
        measurement_uncertainty: Optional 1-sigma uncertainties, used for chi2 and
            as effective-count row weights ``y_i / sigma_i**2``.
        max_iters: Maximum iterations to perform.
        tolerance: Relative max change threshold for convergence.
        chi2_tolerance: Optional stop when chi2 per measurement falls below this
            value. Records ``stop_reason='chi2_target'``; never sets ``converged``.
        floor: Minimum flux/prediction value to avoid divide-by-zero.
        relaxation: Under-relaxation factor (0-1). Lower = more stable, slower.
        prior_strength: Geometric pull toward the initial spectrum after each
            iteration. Zero disables this regularization.
        smoothing_strength: Log-space nearest-neighbour smoothing strength
            applied after each update. Zero disables smoothing.
        convergence_mode: "relative" (default) uses max relative flux change,
            "ddJ" uses Neutron-Unfolding style second derivative criterion.
        verbose: Print convergence progress.
    """

    response, measurements, initial_flux, measurement_uncertainty = (
        _validate_iterative_inputs(
            response,
            measurements,
            initial_flux=initial_flux,
            measurement_uncertainty=measurement_uncertainty,
        )
    )

    n_groups = len(response[0])
    n_meas = len(measurements)

    # Initialize flux
    if initial_flux is not None:
        phi = initial_flux[:]
    else:
        avg_meas = sum(measurements) / len(measurements)
        phi = _default_flux(n_groups, scale=avg_meas / n_groups)

    phi = elementwise_maximum(phi, floor)
    regularization_reference = phi[:]
    # With uncertainties, each row is treated as Poisson data with
    # (y_i / sigma_i)^2 effective counts, i.e. rescaled by y_i / sigma_i^2.
    # That weight keeps the update invariant to the units of any single row;
    # plain 1/sigma^2 would weight rows by the inverse of their magnitude.
    weights = (
        [m / (u * u) if u > 0 else 0.0 for m, u in zip(measurements, measurement_uncertainty)]
        if measurement_uncertainty
        else [1.0 for _ in measurements]
    )

    history: List[Vector] = [phi[:]]
    chi2_history: List[float] = []
    converged = False
    stop_reason = "max_iterations"

    # For ddJ convergence mode (Neutron-Unfolding style)
    J_prev = 0.0
    dJ_prev = 1.0

    for it in range(1, max_iters + 1):
        predicted = matmul(response, phi)
        predicted = [max(p, floor) for p in predicted]

        # Compute chi-squared
        chi2, residuals = _compute_chi_squared(
            response, phi, measurements, measurement_uncertainty, floor
        )
        chi2_per_meas = chi2 / max(n_meas, 1)
        chi2_history.append(chi2_per_meas)

        # Compute J for ddJ mode (Neutron-Unfolding objective)
        if convergence_mode == "ddJ":
            sum_pred = sum(predicted)
            J = sum((p - m) ** 2 for p, m in zip(predicted, measurements)) / max(
                sum_pred, floor
            )
            dJ = J_prev - J
            ddJ = abs(dJ - dJ_prev)
            J_prev = J
            dJ_prev = dJ

        if verbose and it % 100 == 0:
            print(f"  MLEM iter {it}: chi2/n = {chi2_per_meas:.4f}")

        updated: Vector = []
        max_rel_change = 0.0
        for g in range(n_groups):
            numerator = sum(
                weights[i] * response[i][g] * measurements[i] / predicted[i]
                for i in range(n_meas)
            )
            denominator = sum(weights[i] * response[i][g] for i in range(n_meas))
            if denominator <= 0:
                updated.append(phi[g])
                continue

            # Calculate update with relaxation
            target_phi = phi[g] * numerator / denominator
            new_phi = phi[g] + relaxation * (target_phi - phi[g])
            new_phi = max(new_phi, floor)

            max_rel_change = max(
                max_rel_change, abs(new_phi - phi[g]) / max(phi[g], floor)
            )
            updated.append(new_phi)

        phi = _stabilize_iterative_flux(
            updated,
            reference_flux=regularization_reference,
            prior_strength=prior_strength,
            smoothing_strength=smoothing_strength,
            floor=floor,
        )
        history.append(phi[:])

        # Check convergence criteria
        if convergence_mode == "ddJ" and ddJ < tolerance:
            converged = True
            stop_reason = "converged"
            if verbose:
                print(
                    f"  MLEM converged at iter {it}: ddJ = {ddJ:.2e}, chi2/n = {chi2_per_meas:.4f}"
                )
            break
        elif convergence_mode == "relative" and max_rel_change < tolerance:
            converged = True
            stop_reason = "converged"
            if verbose:
                print(
                    f"  MLEM converged at iter {it}: rel_change = {max_rel_change:.2e}, chi2/n = {chi2_per_meas:.4f}"
                )
            break

        if chi2_tolerance is not None and chi2_per_meas < chi2_tolerance:
            # A small residual is a stopping target, not numerical convergence.
            stop_reason = "chi2_target"
            if verbose:
                print(f"  MLEM stopped at chi2 target, iter {it}: chi2/n = {chi2_per_meas:.4f}")
            break

    final_chi2, final_residuals = _compute_chi_squared(
        response, phi, measurements, measurement_uncertainty, floor
    )

    return IterativeSolution(
        flux=phi,
        history=history,
        iterations=it if "it" in dir() else max_iters,
        converged=converged,
        chi_squared=final_chi2 / max(n_meas, 1),
        chi_squared_total=final_chi2,
        n_measurements=n_meas,
        stop_reason=stop_reason,
        chi_squared_history=chi2_history,
        final_residuals=final_residuals,
        diagnostics=merge_flux_diagnostics(
            None,
            phi,
            negative_policy="floor_clamped",
            nonnegativity_enforced=True,
        ),
    )


def gradient_descent(
    response: Matrix,
    measurements: Vector,
    initial_flux: Optional[Vector] = None,
    measurement_uncertainty: Optional[Vector] = None,
    max_iters: int = 10000,
    tolerance: float = 1e-6,
    chi2_tolerance: Optional[float] = None,
    floor: float = 1e-12,
    learning_rate: float = 1.0,
    smoothness_weight: float = 0.01,
    auto_scale: bool = True,
    verbose: bool = False,
) -> IterativeSolution:
    """Gradient descent solver with smoothness regularization (SpecKit-style).

    This solver minimizes: L = MSE(Ax - b) + λ * smoothness_penalty
    where smoothness_penalty = mean(diff(log(x))^2)

    Inspired by the SpecKit neural network approach but without the GUI.

    Args:
        response: Response matrix R_{i,g} (n_meas x n_groups).
        measurements: Measured reaction rates y_i.
        initial_flux: Starting flux guess. Defaults to uniform.
        measurement_uncertainty: Optional 1-sigma uncertainties.
        max_iters: Maximum iterations to perform.
        tolerance: Loss change threshold for convergence.
        chi2_tolerance: Optional stop when chi2 per measurement falls below this
            value. Records ``stop_reason='chi2_target'``; never sets ``converged``.
        floor: Minimum flux value to ensure positivity.
        learning_rate: Step size for gradient updates.
        smoothness_weight: Weight λ for smoothness regularization term.
        auto_scale: Auto-scale flux to match measurement magnitude.
        verbose: Print convergence progress.
    """
    response, measurements, initial_flux, measurement_uncertainty = (
        _validate_iterative_inputs(
            response,
            measurements,
            initial_flux=initial_flux,
            measurement_uncertainty=measurement_uncertainty,
        )
    )

    n_groups = len(response[0])
    n_meas = len(measurements)

    # Initialize flux
    if initial_flux is not None:
        phi = [max(x, floor) for x in initial_flux]
    else:
        avg_meas = sum(measurements) / len(measurements)
        phi = [avg_meas / n_groups for _ in range(n_groups)]

    history: List[Vector] = [phi[:]]
    chi2_history: List[float] = []
    loss_history: List[float] = []
    converged = False
    stop_reason = "max_iterations"

    # Track minimum loss for early stopping
    min_loss = float("inf")
    no_improvement_count = 0
    patience = 1000  # Reset if no improvement for this many iterations

    for it in range(1, max_iters + 1):
        # Compute prediction: Ax
        predicted = matmul(response, phi)
        predicted = [max(p, floor) for p in predicted]

        # Compute error: (Ax - b)
        errors = [p - m for p, m in zip(predicted, measurements)]

        # MSE loss
        mse_loss = sum(e * e for e in errors) / n_meas

        # Smoothness penalty on log(phi)
        log_phi = [math.log(max(p, floor)) for p in phi]
        log_diffs = [log_phi[g + 1] - log_phi[g] for g in range(n_groups - 1)]
        smoothness_penalty = sum(d * d for d in log_diffs) / max(len(log_diffs), 1)

        # Total loss
        loss = mse_loss + smoothness_weight * smoothness_penalty
        loss_history.append(loss)

        # Compute chi-squared
        chi2, residuals = _compute_chi_squared(
            response, phi, measurements, measurement_uncertainty, floor
        )
        chi2_per_meas = chi2 / max(n_meas, 1)
        chi2_history.append(chi2_per_meas)

        if verbose and it % 500 == 0:
            print(f"  GD iter {it}: loss = {loss:.4e}, chi2/n = {chi2_per_meas:.4f}")

        # Auto-scale on first iteration
        if it == 1 and auto_scale:
            sum_pred = sum(predicted)
            sum_meas = sum(measurements)
            if sum_pred > 0 and sum_meas > 0:
                scale_factor = sum_meas / sum_pred
                phi = [p * scale_factor for p in phi]
                if verbose:
                    print(f"  Auto-scaled flux by factor {scale_factor:.4e}")
                continue  # Re-evaluate with scaled flux

        # Gradient: dL/dx = (2/n) * A^T @ (Ax - b)
        gradient = []
        for g in range(n_groups):
            grad_g = sum(
                2.0 * errors[i] * response[i][g] / n_meas for i in range(n_meas)
            )

            # Add smoothness gradient contribution
            if smoothness_weight > 0 and n_groups > 1:
                if g > 0:
                    dlog_left = log_phi[g] - log_phi[g - 1]
                    grad_g += (
                        2.0 * smoothness_weight * dlog_left / (phi[g] * (n_groups - 1))
                    )
                if g < n_groups - 1:
                    dlog_right = log_phi[g] - log_phi[g + 1]
                    grad_g += (
                        2.0 * smoothness_weight * dlog_right / (phi[g] * (n_groups - 1))
                    )

            gradient.append(grad_g)

        # Update flux: x = x - lr * gradient
        max_rel_change = 0.0
        updated = []
        for g in range(n_groups):
            new_phi = phi[g] - learning_rate * gradient[g]
            new_phi = max(new_phi, floor)  # Enforce positivity
            max_rel_change = max(
                max_rel_change, abs(new_phi - phi[g]) / max(phi[g], floor)
            )
            updated.append(new_phi)

        phi = updated
        history.append(phi[:])

        # Check for convergence
        if chi2_tolerance is not None and chi2_per_meas < chi2_tolerance:
            # A small residual is a stopping target, not numerical convergence.
            stop_reason = "chi2_target"
            if verbose:
                print(f"  GD stopped at chi2 target, iter {it}: chi2/n = {chi2_per_meas:.4f}")
            break

        # Check loss plateau
        if len(loss_history) >= 500:
            recent_losses = loss_history[-500:]
            loss_range = max(recent_losses) - min(recent_losses)
            if loss_range / max(max(recent_losses), floor) < 1e-5:
                converged = True
                stop_reason = "converged"
                if verbose:
                    print(f"  GD converged at iter {it}: loss plateau detected")
                break

        # Track improvement and reset if stuck
        if loss < min_loss:
            min_loss = loss
            no_improvement_count = 0
        else:
            no_improvement_count += 1

        if no_improvement_count >= patience:
            no_improvement_count = 0
            min_loss = float("inf")
            # Reset with some noise for exploration
            if verbose:
                print(f"  GD iter {it}: resetting due to no improvement")

    final_chi2, final_residuals = _compute_chi_squared(
        response, phi, measurements, measurement_uncertainty, floor
    )

    return IterativeSolution(
        flux=phi,
        history=history,
        iterations=it if "it" in dir() else max_iters,
        converged=converged,
        chi_squared=final_chi2 / max(n_meas, 1),
        chi_squared_total=final_chi2,
        n_measurements=n_meas,
        stop_reason=stop_reason,
        chi_squared_history=chi2_history,
        final_residuals=final_residuals,
        diagnostics=merge_flux_diagnostics(
            None,
            phi,
            negative_policy="floor_clamped",
            nonnegativity_enforced=True,
        ),
    )
