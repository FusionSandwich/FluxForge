"""Jinja2-backed reporting engine for the modern Qt shell."""

from __future__ import annotations

from dataclasses import dataclass, field
import base64
from hashlib import sha256
from importlib import import_module
from io import BytesIO
import json
from pathlib import Path
from typing import Any
from zipfile import ZIP_DEFLATED, ZipFile

from fluxforge.reporting.instrument_provenance import validate_instructional_snapshot

try:
    from jinja2 import Environment, FileSystemLoader, select_autoescape
except ImportError as exc:  # pragma: no cover - optional dependency branch
    Environment = None
    FileSystemLoader = None
    select_autoescape = None
    _JINJA2_IMPORT_ERROR = exc
else:  # pragma: no cover - exercised when reporting extras are installed
    _JINJA2_IMPORT_ERROR = None


DEFAULT_TEMPLATE_DIR = Path(__file__).resolve().parent / "templates"


def _load_weasyprint_html():
    """Load WeasyPrint's HTML entrypoint on demand."""

    try:
        module = import_module("weasyprint")
    except Exception as exc:  # pragma: no cover - optional/native dependency branch
        raise RuntimeError(
            "PDF export requires a working WeasyPrint installation and its "
            "native libraries."
        ) from exc
    return module.HTML


@dataclass(frozen=True)
class ReportTemplateSpec:
    """Minimal report-template description."""

    name: str
    description: str
    required_context_keys: tuple[str, ...] = ()
    template_file: str | None = None


@dataclass(frozen=True)
class ReportRenderResult:
    """Rendered report payload."""

    template_name: str
    html: str
    context: dict[str, Any]


@dataclass
class ReportingEngine:
    """Jinja2 template registry and export surface."""

    templates: dict[str, ReportTemplateSpec] = field(default_factory=dict)
    template_dir: Path = field(default_factory=lambda: DEFAULT_TEMPLATE_DIR)
    _environment: Any | None = field(init=False, default=None, repr=False)

    def __post_init__(self) -> None:
        self.template_dir = Path(self.template_dir)
        if not self.templates:
            self._register_bundled_templates()

    def template_backend_available(self) -> bool:
        """Return whether the HTML template backend is installed."""

        return _JINJA2_IMPORT_ERROR is None

    def _ensure_environment(self):
        if self._environment is not None:
            return self._environment
        if _JINJA2_IMPORT_ERROR is not None:
            raise RuntimeError(
                "HTML report rendering requires the optional reporting extra "
                "(`Jinja2`)."
            ) from _JINJA2_IMPORT_ERROR
        self._environment = Environment(
            loader=FileSystemLoader(str(self.template_dir)),
            autoescape=select_autoescape(["html", "xml"]),
        )
        return self._environment

    def register(self, template: ReportTemplateSpec) -> None:
        self.templates[template.name] = template

    def _register_bundled_templates(self) -> None:
        self.register(
            ReportTemplateSpec(
                name="standard_lab",
                description=(
                    "Standard laboratory review template with residuals and provenance."
                ),
                required_context_keys=(
                    "title",
                    "spectrum_image",
                    "calibration_curve",
                    "calibration_residuals",
                    "efficiency_curve",
                    "efficiency_residuals",
                    "residuals_grid",
                    "peak_table",
                    "activity_table",
                    "astm_status_table",
                    "qa_status_snapshot",
                    "provenance",
                ),
                template_file="standard_lab.html.j2",
            )
        )
        self.register(
            ReportTemplateSpec(
                name="astm_compliance",
                description=(
                    "ASTM-oriented compliance report with QA and lock summaries."
                ),
                required_context_keys=(
                    "title",
                    "astm_status_table",
                    "qa_status_snapshot",
                    "peak_table",
                    "activity_table",
                    "residuals_grid",
                    "provenance",
                ),
                template_file="astm_compliance.html.j2",
            )
        )
        self.register(
            ReportTemplateSpec(
                name="batch_summary",
                description="Aggregate batch-analysis summary with per-spectrum rows.",
                required_context_keys=(
                    "title",
                    "batch_rows",
                    "aggregate_csv",
                    "provenance",
                ),
                template_file="batch_summary.html.j2",
            )
        )

    def bundled_templates(self) -> tuple[ReportTemplateSpec, ...]:
        return tuple(self.templates.values())

    def can_export_pdf(self) -> bool:
        """Return whether PDF export support is available in the environment."""

        if not self.template_backend_available():
            return False
        try:
            _load_weasyprint_html()
        except RuntimeError:
            return False
        return True

    def render(self, template_name: str, context: dict[str, Any]) -> ReportRenderResult:
        if "run_snapshot" in context:
            validate_instructional_snapshot(context["run_snapshot"])
        if template_name not in self.templates:
            raise KeyError(f"Unknown template {template_name!r}")
        template = self.templates[template_name]
        missing = [key for key in template.required_context_keys if key not in context]
        if missing:
            raise KeyError(
                f"Template {template_name!r} missing context keys: {', '.join(missing)}"
            )
        template_file = template.template_file or f"{template_name}.html.j2"
        html = self._ensure_environment().get_template(template_file).render(**context)
        return ReportRenderResult(
            template_name=template_name, html=html, context=dict(context)
        )

    def export_html(
        self,
        template_name: str,
        context: dict[str, Any],
        path: str | Path,
    ) -> Path:
        rendered = self.render(template_name, context)
        resolved = Path(path)
        resolved.parent.mkdir(parents=True, exist_ok=True)
        resolved.write_text(rendered.html, encoding="utf-8")
        return resolved

    def export_pdf(
        self,
        template_name: str,
        context: dict[str, Any],
        path: str | Path,
    ) -> Path:
        """Render one bundled template to PDF via WeasyPrint."""

        rendered = self.render(template_name, context)
        resolved = Path(path)
        resolved.parent.mkdir(parents=True, exist_ok=True)
        html_class = _load_weasyprint_html()
        html_class(string=rendered.html, base_url=str(self.template_dir)).write_pdf(
            str(resolved)
        )
        return resolved

    def export_bundle(
        self,
        template_name: str,
        context: dict[str, Any],
        path: str | Path,
        *,
        include_pdf: bool = False,
    ) -> Path:
        """Export one captured run as a ZIP, without replacing an existing file.

        HTML embeds its images for standalone use. The JSON companion preserves
        typed inputs and tables, with separately hashed PNG assets. All rendering
        finishes before the output is created, so PDF failures leave no bundle.
        """
        snapshot = json.loads(json.dumps(context["run_snapshot"], allow_nan=False))
        if snapshot.get("schema") != "fluxforge.gui_report_snapshot.v1":
            raise ValueError("A current Qt report snapshot is required.")
        rendered = self.render(template_name, context)
        entries = {"report.html": rendered.html.encode("utf-8")}
        for index, view in enumerate(snapshot["views"]):
            asset = f"views/{index:03d}.png"
            pixels = base64.b64decode(view.pop("png_base64"), validate=True)
            if sha256(pixels).hexdigest() != view["sha256"]:
                raise ValueError("Captured plot hash does not match its pixels.")
            view["asset"] = asset
            entries[asset] = pixels
        entries["snapshot.json"] = json.dumps(
            snapshot, indent=2, allow_nan=False
        ).encode("utf-8")
        if include_pdf:
            html_class = _load_weasyprint_html()
            entries["report.pdf"] = html_class(
                string=rendered.html, base_url=str(self.template_dir)
            ).write_pdf()
        manifest = {
            "schema": "fluxforge.gui_report_bundle.v1",
            "template": template_name,
            "captured_at": snapshot["captured_at"],
            "scientific_admission": False,
            "files": {
                name: {"sha256": sha256(data).hexdigest(), "bytes": len(data)}
                for name, data in entries.items()
            },
        }
        entries["manifest.json"] = json.dumps(manifest, indent=2).encode("utf-8")
        memory = BytesIO()
        with ZipFile(memory, "w", compression=ZIP_DEFLATED) as archive:
            for name, data in entries.items():
                archive.writestr(name, data)
        resolved = Path(path)
        resolved.parent.mkdir(parents=True, exist_ok=True)
        with resolved.open("xb") as output:
            output.write(memory.getvalue())
        return resolved
